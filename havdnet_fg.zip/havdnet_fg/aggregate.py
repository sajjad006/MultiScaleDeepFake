"""
aggregate.py -- combine seeds into paper numbers.

  python aggregate.py --runs runs/main_s* --name "HAVDNet-v2"
  python aggregate.py --runs runs/main_s* --eval jitter40 --name "jitter 40ms"
  python aggregate.py --runs runs/fuse_concat_s* runs/fuse_xattn_s* ... --table   # one row per glob

Reports mean +- std over seeds and a stratified-bootstrap 95% CI of the seed-averaged prediction
(only when all runs share the same evaluated videos). Appends a markdown row to --md.
"""
import argparse
import glob
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from sklearn.metrics import balanced_accuracy_score, f1_score, roc_auc_score

from engine import all_metrics, eer


def load(run, ev):
    f = Path(run) / ("test_preds.npz" if ev == "test" else f"eval_{ev}/preds.npz")
    d = np.load(f, allow_pickle=True)
    vocab = json.load(open(Path(run) / "split.json")).get("method_vocab")
    return {k: d[k] for k in d.files}, vocab


def ms(vals):
    v = [x for x in vals if x is not None and not np.isnan(x)]
    return (float(np.mean(v)), float(np.std(v, ddof=1)) if len(v) > 1 else 0.0) if v else (np.nan, np.nan)


def summarize(runs, ev, n_boot=1000):
    preds = [load(r, ev) for r in runs]
    mets = [all_metrics(p, v) for p, v in preds]
    rows = {
        "4c_acc": [m["four_class"]["acc"] for m in mets],
        "4c_bal_acc": [m["four_class"]["bal_acc"] for m in mets],
        "4c_macro_f1": [m["four_class"]["macro_f1"] for m in mets],
        "4c_auc": [m["four_class"].get("auc_ovr") for m in mets],
        "bin_acc": [m["binary"]["acc"] for m in mets],
        "bin_bal_acc": [m["binary"]["bal_acc"] for m in mets],
        "bin_auc": [m["binary"].get("auc") for m in mets],
        "bin_eer": [m["binary"].get("eer") for m in mets],
        "method_acc": [m["method"]["acc"] if m["method"] else None for m in mets],
    }
    out = {k: ms(v) for k, v in rows.items()}
    out["n_runs"], out["n_test"] = len(runs), int(len(preds[0][0]["labels"]))
    out["n_per_class"] = mets[0]["n_per_class"]
    same = all(np.array_equal(p["keys"], preds[0][0]["keys"]) for p, _ in preds)
    if same:
        y = preds[0][0]["labels"]
        P = [p["probs"] for p, _ in preds]
        rng = np.random.default_rng(0)
        by_c = [np.where(y == c)[0] for c in np.unique(y)]
        boots = defaultdict(list)
        pm = np.mean(P, 0)
        for _ in range(n_boot):
            idx = np.concatenate([rng.choice(ix, len(ix)) for ix in by_c])
            yy, pp = y[idx], pm[idx]
            pred = pp.argmax(1)
            boots["4c_bal_acc"].append(balanced_accuracy_score(yy, pred))
            boots["4c_macro_f1"].append(f1_score(yy, pred, average="macro"))
            yb = (yy != 0).astype(int)
            if 0 < yb.sum() < len(yb):
                boots["bin_auc"].append(roc_auc_score(yb, 1 - pp[:, 0]))
                boots["bin_eer"].append(eer(yb, 1 - pp[:, 0]))
        out["ci95"] = {k: np.percentile(v, [2.5, 97.5]).tolist() for k, v in boots.items()}
    return out


def fmt(mstd, pct=True):
    m, s = mstd
    if np.isnan(m):
        return "--"
    k = 100 if pct else 1
    return f"{m * k:.2f} ± {s * k:.2f}"


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--runs", nargs="+", required=True, help="run dirs or globs")
    p.add_argument("--eval", default="test", help="'test' or an evaluate.py --tag")
    p.add_argument("--name", default=None)
    p.add_argument("--table", action="store_true", help="treat each --runs glob as one table row")
    p.add_argument("--md", default="results.md")
    a = p.parse_args()

    def expand(g):   # run globs like runs/fav/gt_s[0-9]* ; plain dirs pass through
        return sorted(p for p in glob.glob(g) if Path(p).is_dir())
    groups = [(Path(g).name.replace("_s[0-9]*", "").replace("_s*", ""), expand(g)) for g in a.runs] if a.table else \
             [(a.name or a.runs[0], sorted(sum((expand(g) for g in a.runs), [])))]
    lines = []
    hdr = ("| variant | n_seeds | 4-class bal. acc | 4-class macro-F1 | binary AUC | binary EER | "
           "binary bal. acc | generator acc |\n|---|---|---|---|---|---|---|---|")
    for name, runs in groups:
        runs = [r for r in runs if (Path(r) / ("test_preds.npz" if a.eval == "test" else f"eval_{a.eval}/preds.npz")).exists()]
        if not runs:
            print(f"[skip] {name}: no finished runs"); continue
        s = summarize(runs, a.eval)
        row = (f"| {name} | {s['n_runs']} | {fmt(s['4c_bal_acc'])} | {fmt(s['4c_macro_f1'])} | "
               f"{fmt(s['bin_auc'])} | {fmt(s['bin_eer'])} | {fmt(s['bin_bal_acc'])} | {fmt(s['method_acc'])} |")
        lines.append(row)
        print(json.dumps({"variant": name, **s}, indent=1, default=float))
    if lines:
        prev = Path(a.md).read_text().rstrip().splitlines() if Path(a.md).exists() else []
        with open(a.md, "a") as f:
            if not prev or not prev[-1].startswith("|"):
                f.write(hdr + "\n")
            f.write("\n".join(lines) + "\n")
        print("\n" + hdr + "\n" + "\n".join(lines))


if __name__ == "__main__":
    main()
