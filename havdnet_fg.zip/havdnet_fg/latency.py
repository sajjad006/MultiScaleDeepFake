"""
latency.py -- deployment cost table (reviewer UydU): params, GFLOPs and per-clip latency per stage.

  python latency.py --run runs/fav/main_s0 runs/fav/gt_s0          # trainable model(s) only
  python latency.py --run runs/fav/gt_s0 --manifest fav_manifest.csv --n 20   # + full preprocessing path per clip
Writes latency.json and appends a markdown table to latency.md.
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch

from common import FR_SYL, FR_WORD, MAX_SENT, MAX_SYL, MAX_WORD
from havdnet_v2 import HAVDNetV2


def fake_batch(B, dev, n=(30, 10, 8)):
    L = torch.tensor([list(n)] * B, device=dev)
    return {"lips": torch.randn(B, MAX_SYL, FR_SYL, 3, 48, 96, device=dev).half(),
            "clip_word": torch.randn(B, MAX_WORD, FR_WORD, 512, device=dev).half(),
            "arcface": torch.randn(B, MAX_SENT, 512, device=dev).half(),
            "a_syl": torch.randn(B, MAX_SYL, 1024, device=dev).half(),
            "a_word": torch.randn(B, MAX_WORD, 1024, device=dev).half(),
            "a_sent": torch.randn(B, MAX_SENT, 1024, device=dev).half(), "len": L}


def timeit(fn, dev, reps=20, warm=5):
    for _ in range(warm):
        fn()
    if dev.startswith("cuda"):
        torch.cuda.synchronize()
    t = time.perf_counter()
    for _ in range(reps):
        fn()
    if dev.startswith("cuda"):
        torch.cuda.synchronize()
    return (time.perf_counter() - t) / reps * 1000


@torch.no_grad()
def model_cost(run, dev):
    ck = torch.load(Path(run) / "best.pt", map_location=dev, weights_only=False)
    m = HAVDNetV2(ck["cfg"]).to(dev).eval()
    m.load_state_dict(ck["state"])
    b1 = fake_batch(1, dev)
    from torch.utils.flop_counter import FlopCounterMode
    fc = FlopCounterMode(display=False)
    with fc:
        m(b1)
    amp = dev.startswith("cuda")
    with torch.autocast(device_type=dev.split(":")[0], dtype=torch.float16, enabled=amp):
        ms1 = timeit(lambda: m(b1), dev)
        b16 = fake_batch(16, dev)
        ms16 = timeit(lambda: m(b16), dev, reps=10) / 16
    return {"run": str(run), "fusion": ck["cfg"]["fusion"],
            "params_M": sum(p.numel() for p in m.parameters()) / 1e6,
            "gflops_per_clip": fc.get_total_flops() / 1e9, "ms_per_clip_bs1": ms1, "ms_per_clip_bs16": ms16}


def pipeline_cost(manifest, n, smoke=False):
    """Per-clip cost of the full preprocessing path on n real videos (single process):
    decode + landmarks + crops (CPU), CLIP / ArcFace / XLSR (GPU), WhisperX + alignment (GPU)."""
    import preprocess as P
    rows = P.read_manifest(manifest)[:n]
    P.cpu_init(smoke)
    opt = {"crf": None, "scale": None, "snr": None, "mesh_max_side": 640, "smoke": smoke}
    m = P.GPUModels(0, smoke)
    cpu, gpu, frames, dur = [], {"clip": [], "arc": [], "xlsr": []}, [], []
    for r in rows:
        res = P.cpu_stage((r, opt))
        if res["err"]:
            continue
        cpu.append(res["cpu_sec"]); frames.append(len(res["ok"])); dur.append(len(res["ok"]) / res["fps"])
        for k, fn, x in (("clip", m.clip_feats, res["faces"]), ("arc", m.arc_feats, res["arcs"]), ("xlsr", m.xlsr_feats, res["wav"])):
            if m.dev.startswith("cuda"):
                torch.cuda.synchronize()
            t = time.perf_counter(); fn(x)
            if m.dev.startswith("cuda"):
                torch.cuda.synchronize()
            gpu[k].append(time.perf_counter() - t)
    out = {"n": len(cpu), "mean_clip_sec": float(np.mean(dur)), "mean_frames": float(np.mean(frames)),
           "cpu_decode_landmarks_crops_s": float(np.mean(cpu))}
    out.update({f"gpu_{k}_s": float(np.mean(v[1:] or v)) for k, v in gpu.items()})
    if not smoke:
        try:
            import whisperx
            wm = whisperx.load_model("large-v3-turbo", device="cuda", compute_type="float16")
            ts = []
            for r in rows[:n]:
                wav = P.load_audio(r["path"])
                t = time.perf_counter(); wm.transcribe(wav, batch_size=16, language="en" if r.get("lang_code") in ("", "en") else r.get("lang_code"))
                ts.append(time.perf_counter() - t)
            out["gpu_asr_transcribe_s"] = float(np.mean(ts[1:] or ts))
        except Exception as e:
            out["asr_note"] = f"skipped: {e}"
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run", nargs="+", required=True)
    ap.add_argument("--manifest", default=None, help="also time the preprocessing path on --n of these videos")
    ap.add_argument("--n", type=int, default=10)
    ap.add_argument("--smoke_test", action="store_true")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    a = ap.parse_args()
    res = {"device": torch.cuda.get_device_name() if a.device.startswith("cuda") else "cpu",
           "models": [model_cost(r, a.device) for r in a.run]}
    if a.manifest:
        res["preprocessing"] = pipeline_cost(a.manifest, a.n, a.smoke_test)
    json.dump(res, open("latency.json", "w"), indent=1)
    lines = ["| model | fusion | params (M) | GFLOPs/clip | ms/clip (bs1) | ms/clip (bs16) |", "|---|---|---|---|---|---|"]
    for m in res["models"]:
        lines.append(f"| {Path(m['run']).name} | {m['fusion']} | {m['params_M']:.2f} | {m['gflops_per_clip']:.2f} | "
                     f"{m['ms_per_clip_bs1']:.2f} | {m['ms_per_clip_bs16']:.2f} |")
    with open("latency.md", "a") as f:
        f.write(f"\ndevice: {res['device']}\n" + "\n".join(lines) + "\n")
        for k in ("preprocessing",):
            if k in res:
                f.write(f"\n{k}: " + json.dumps(res[k]) + "\n")
    print(json.dumps(res, indent=1))


if __name__ == "__main__":
    main()
