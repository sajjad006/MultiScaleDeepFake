"""data.py -- dataset over the per-frame feature store written by preprocess.py, splits, collate.

Segment pooling happens here (not offline): words/syllables from align.json define frame windows,
which select per-frame CLIP / ArcFace / lip crops and average the 40 ms XLSR rows. Passing
perturb=(sigma_ms, shift_ms, drop_p) simulates forced-alignment errors at test time with no
re-extraction.
"""
import json
import random
from collections import Counter, defaultdict
from pathlib import Path

import cv2
import numpy as np
import torch
from sklearn.model_selection import GroupShuffleSplit
from torch.utils.data import Dataset

from common import (FR_SYL, FR_WORD, MAX_SENT, MAX_SYL, MAX_WORD, method_tokens, pad_window,
                    perturb_alignment, sample_frames, visual_method)

LIP_MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 1, 3, 1, 1)
LIP_STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 1, 3, 1, 1)
TRUE = ("1", "true", "True", True, 1)


def scan_store(store, allow_smoke=False):
    """Every video with BOTH meta.json (features) and align.json (ASR) and >= 1 aligned word."""
    store = Path(store)
    infos, no_align, no_words = [], 0, 0
    for mp in sorted(store.glob("*/meta.json")):
        ap = mp.parent / "align.json"
        if not ap.exists():
            no_align += 1
            continue
        m, al = json.load(open(mp)), json.load(open(ap))
        if not al.get("words"):
            no_words += 1
            continue
        m["label"] = int(m["label"])
        m["method_from_csv"] = m.get("method_from_csv") in TRUE
        m["align"] = {"words": al["words"], "syllables": al["syllables"]}
        m.setdefault("ethnicity", "unknown"); m.setdefault("gender", "unknown")
        m.setdefault("language", al.get("language", "unknown"))
        infos.append(m)
    if not infos:
        raise SystemExit(f"no usable videos in {store} -- run preprocess.py (features + asr) first")
    if no_align or no_words:
        print(f"[store] skipped {no_align} videos without alignment, {no_words} with no recognised words")
    smoke = sum(bool(i.get("smoke_test")) for i in infos)
    if smoke and not allow_smoke:
        raise SystemExit(f"{smoke} store entries are SMOKE-TEST (stub) features; pass --allow_smoke for plumbing tests.")
    return infos


# ------------------------------------------------------------------ splitting
def group_ids(infos, mode="identity"):
    """identity : the identity folder (target video's speaker).
    component  : connected components over {identity, source, target1, target2}. Stricter: a
                 face swapped INTO a test video can't belong to a training speaker. If FakeAVCeleb's
                 swap graph collapses into a few giant components this is unusable -- we report it."""
    if mode == "identity":
        return [i["identity"] for i in infos]
    if mode == "group":                       # explicit source-video group (PolyGlotFake manifests)
        missing = sum(1 for i in infos if not i.get("group"))
        if missing:
            raise SystemExit(f"--group_by group: {missing} videos have no 'group' field in meta.json")
        return [i["group"] for i in infos]
    parent = {}

    def find(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for i in infos:
        ids = [x for x in (i["identity"], i.get("source"), i.get("target1"), i.get("target2"))
               if x and x not in ("-", "unknown")]
        for x in ids[1:]:
            parent[find(ids[0])] = find(x)
        find(ids[0])
    g = [find(i["identity"]) for i in infos]
    sizes = Counter(g)
    print(f"[split] component grouping: {len(sizes)} groups, largest = "
          f"{max(sizes.values()) / len(g):.1%} of videos")
    return g


def make_split(infos, test_size=0.2, val_frac=0.1, seed=0, group_by="identity"):
    groups = group_ids(infos, group_by)
    if len(set(groups)) < 5:
        raise SystemExit(f"only {len(set(groups))} groups under group_by={group_by}; use 'identity'")
    idx = np.arange(len(infos))
    tv, te = next(GroupShuffleSplit(1, test_size=test_size, random_state=seed).split(idx, groups=groups))
    tvg = [groups[i] for i in tv]
    tr, va = next(GroupShuffleSplit(1, test_size=val_frac, random_state=seed).split(tv, groups=tvg))
    sp = {"train": [infos[tv[i]]["key"] for i in tr], "val": [infos[tv[i]]["key"] for i in va],
          "test": [infos[i]["key"] for i in te]}
    g = {k: {groups[i] for i, inf in enumerate(infos) if inf["key"] in set(v)} for k, v in sp.items()}
    assert not (g["train"] & g["test"]) and not (g["val"] & g["test"]) and not (g["train"] & g["val"])
    return sp


def parse_filter(f):
    return [tuple(kv.split("=", 1)) for kv in f.split(",")] if f else []


def filter_split(sp, infos, train_groups=None, holdout_method=None, train_filter=None):
    """train_groups: 'African|men' restricts TRAIN/VAL to that demographic (test untouched ->
    a full cross-demographic row from one run). holdout_method: drop every video whose generator
    contains that token from TRAIN/VAL (test untouched -> unseen-generator protocol)."""
    by = {i["key"]: i for i in infos}
    out = {k: list(v) for k, v in sp.items()}
    for part in ("train", "val"):
        keep = out[part]
        if train_groups:
            eth, gen = train_groups.split("|")
            keep = [k for k in keep if by[k]["ethnicity"] == eth and by[k]["gender"] == gen]
        for k_, v_ in parse_filter(train_filter):
            keep = [k for k in keep if str(by[k].get(k_, "")) == v_]
        if holdout_method:
            keep = [k for k in keep if holdout_method not in method_tokens(by[k]["method"])]
        out[part] = keep
    return out


def method_vocab(infos, keys):
    """Visual-generator vocabulary from TRAIN videos with fake video. Disabled (None) if the
    labels are just category placeholders (preprocessing run without --meta)."""
    by = {i["key"]: i for i in infos}
    vm = Counter(visual_method(by[k]["method"]) for k in keys if by[k]["label"] in (2, 3))
    vm.pop("", None); vm.pop("none", None)
    if len(vm) < 2 or not any(by[k].get("method_from_csv") for k in keys):
        return None
    return sorted(vm)


# ------------------------------------------------------------------ dataset
class _Video:
    """Memory-mapped view of one store folder (opened lazily inside each DataLoader worker)."""
    def __init__(self, d):
        self.clip = np.load(d / "clip.npy", mmap_mode="r")
        self.arc = np.load(d / "arc.npy", mmap_mode="r")
        self.ok = np.load(d / "face_ok.npy")
        self.xlsr = np.load(d / "xlsr.npy", mmap_mode="r")
        self.off = np.load(d / "lips_off.npy")
        self.lips = np.memmap(d / "lips.bin", dtype=np.uint8, mode="r") if self.off[-1] > 0 else None
        self.valid = np.flatnonzero(self.ok)

    def lip(self, i):
        a, b = self.off[i], self.off[i + 1]
        img = cv2.imdecode(np.asarray(self.lips[a:b]), cv2.IMREAD_COLOR)
        return img[:, :, ::-1]                                               # BGR -> RGB, (48, 96, 3)


def nearest_valid(valid, idx, lo, hi):
    """Replace each frame index by the nearest frame with a detected face inside [lo, hi)."""
    if valid.size == 0:
        return None
    pool = valid[(valid >= lo) & (valid < hi)]
    if pool.size == 0:
        return None
    return [int(pool[np.abs(pool - i).argmin()]) for i in idx]


class StoreDataset(Dataset):
    def __init__(self, store, infos, keys, augment=False, mvocab=None, perturb=None, perturb_seed=0):
        self.store = Path(store)
        by = {i["key"]: i for i in infos}
        missing = [k for k in keys if k not in by]
        if missing:
            raise SystemExit(f"{len(missing)} split keys are missing from store {store} "
                             "(not preprocessed, or ASR found no words)")
        self.items = [by[k] for k in keys]
        self.augment = augment
        self.mvocab = {m: i for i, m in enumerate(mvocab)} if mvocab else None
        self.perturb = tuple(perturb) if perturb else (0.0, 0.0, 0.0)
        self.pseed = perturb_seed
        self._open = {}

    def __len__(self):
        return len(self.items)

    def labels(self):
        return [i["label"] for i in self.items]

    def _video(self, key):
        if key not in self._open:
            if len(self._open) > 64:
                self._open.clear()
            self._open[key] = _Video(self.store / key)
        return self._open[key]

    def __getitem__(self, i):
        inf = self.items[i]
        V = self._video(inf["key"])
        fps, T = float(inf["fps"]), int(inf["n_frames"])
        hz, Ta = float(inf.get("xlsr_hz", 25.0)), V.xlsr.shape[0]
        sigma, shift, drop = self.perturb
        words, syls = inf["align"]["words"], inf["align"]["syllables"]
        if sigma > 0 or drop > 0:
            words, syls = perturb_alignment(words, syls, sigma, drop, seed=self.pseed + int(inf["key"][:8], 16) % 100000,
                                            duration=T / fps)
        sh = shift / 1000.0

        def apool(group, s, e):
            a = max(0, int(np.floor((s + sh) * hz)))
            b = min(Ta, max(a + 1, int(np.ceil((e + sh) * hz))))
            return torch.from_numpy(np.asarray(V.xlsr[a:b, group], dtype=np.float32).mean(0)) if b > a else None

        def segments(segs, nfr, group, mx):
            out = []
            for s in segs:
                sf, ef = pad_window(round(s["start"] * fps), round(s["end"] * fps), T)
                idx = nearest_valid(V.valid, sample_frames(sf, ef, nfr), sf, ef)
                if idx is None:
                    continue
                a = apool(group, sf / fps, ef / fps)
                if a is None:
                    continue
                out.append((idx, a))
                if len(out) == mx:
                    break
            return out

        syl = segments(syls, FR_SYL, 0, MAX_SYL)
        wrd = segments(words, FR_WORD, 1, MAX_WORD)
        sent = []
        for k in range(int(T / fps) + 1):                                    # 1-s slots, as in the paper
            c = int(round(k * fps))
            lo, hi = max(0, c - int(fps / 2)), min(T, c + int(fps / 2) + 1)
            idx = nearest_valid(V.valid, [min(c, T - 1)], lo, hi)
            a = apool(2, lo / fps, hi / fps) if idx is not None else None
            if a is not None:
                sent.append((idx[0], a))
            if len(sent) == MAX_SENT:
                break

        lips = torch.zeros(MAX_SYL, FR_SYL, 48, 96, 3, dtype=torch.uint8)
        for si, (idx, _) in enumerate(syl):
            for fj, f in enumerate(idx):
                lips[si, fj] = torch.from_numpy(np.ascontiguousarray(V.lip(f)))
        lips = lips.permute(0, 1, 4, 2, 3).float().div_(255)
        n = len(syl)
        if self.augment and n:                       # class-agnostic photometric + flip, one draw per video
            b, c = random.uniform(0.8, 1.2), random.uniform(0.8, 1.2)
            m = lips[:n].mean()
            lips[:n] = ((lips[:n] - m) * c + m * b).clamp(0, 1)
            if random.random() < 0.5:
                lips[:n] = lips[:n].flip(-1)
        lips = (lips - LIP_MEAN[0]) / LIP_STD[0]
        lips[n:] = 0

        def stack(rows, n_max, shape):
            out = torch.zeros(n_max, *shape, dtype=torch.float16)
            if rows:
                out[:len(rows)] = torch.stack(rows).to(torch.float16)
            return out

        cw = [torch.from_numpy(np.asarray(V.clip[idx], dtype=np.float32)) for idx, _ in wrd]
        arc = [torch.from_numpy(np.asarray(V.arc[f], dtype=np.float32)) for f, _ in sent]
        vm = visual_method(inf.get("method", "")) if self.mvocab else ""
        return {
            "lips": lips.half(),
            "clip_word": stack(cw, MAX_WORD, (FR_WORD, 512)),
            "arcface": stack(arc, MAX_SENT, (512,)),
            "a_syl": stack([a for _, a in syl], MAX_SYL, (1024,)),
            "a_word": stack([a for _, a in wrd], MAX_WORD, (1024,)),
            "a_sent": stack([a for _, a in sent], MAX_SENT, (1024,)),
            "len": torch.tensor([len(syl), len(wrd), len(sent)]),
            "label": inf["label"],
            "method": self.mvocab.get(vm, -1) if self.mvocab else -1,
            "key": inf["key"],
        }


def collate(batch):
    out = {k: torch.stack([b[k] for b in batch]) for k in
           ("lips", "clip_word", "arcface", "a_syl", "a_word", "a_sent", "len")}
    out["label"] = torch.tensor([b["label"] for b in batch])
    out["method"] = torch.tensor([b["method"] for b in batch])
    out["key"] = [b["key"] for b in batch]
    return out


def to_device(batch, dev):
    return {k: (v.to(dev, non_blocking=True) if torch.is_tensor(v) else v) for k, v in batch.items()}


def demographics(infos, keys, fields=("ethnicity", "gender")):
    by = {i["key"]: i for i in infos}
    c = defaultdict(Counter)
    for k in keys:
        c[tuple(by[k].get(f, "unknown") for f in fields)][by[k]["label"]] += 1
    return c
