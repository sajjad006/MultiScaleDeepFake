"""
game_theory.py -- the two games in HAVDNet-GT, each with an explicit definition and solution concept.

GAME 1  Cooperative TU game over evidence sources (fusion)
  Players  N = {V_syl, V_word, V_sent, A_syl, A_word, A_sent}             (n = 6)
  Value    v(S) = log C - H( p_theta(. | S) )                             (nats of evidence)
           p_theta(.|S) is a value network evaluated on coalition S: players outside S are
           replaced by learned 'absent' embeddings, and the sync score s_k is visible only when
           BOTH V_k and A_k are in S (sync is a property of the pair, so its credit is shared).
  Solution exact Shapley value phi_i = sum_{S not containing i} |S|!(n-|S|-1)!/n! [v(S+i) - v(S)],
           computed over all 2^6 = 64 coalitions in one batched pass (no sampling).
  Use      fusion weights w = proportional allocation of the positive Shapley credit,
           f = sum_i w_i t_i.  Axioms inherited: efficiency (sum phi = v(N) - v(empty)),
           symmetry, null player (a missing/absent player gets phi = 0 exactly), additivity.
  Training the characteristic function: every coalition is supervised with the event it can
           identify -- 4-class if it holds both modalities, video-fake vs not if visual-only,
           audio-fake vs not if audio-only (marginals of the same 4-way distribution).

GAME 2  Bargaining game between learning objectives (optimisation)
  Players  K objectives {L_AV (main), L_V (visual coalition), L_A (audio coalition)}
  Utility  u_k(d) = g_k^T d for a shared-parameter update d, disagreement point 0
  Solution Nash bargaining solution  d* = sum_k alpha_k g_k  with  (G G^T) alpha = 1/alpha
           (Navon et al., ICML 2022, Thm 5.4), found here as the unique minimiser of the strictly
           convex  F(alpha) = 1/2 alpha^T M alpha - sum log alpha  (M = G G^T).
           Properties: Pareto optimal, invariant to rescaling any loss, symmetric -- so the
           dominant visual objective cannot starve the audio branch (modality imbalance).
"""
import math
from itertools import product

import torch
import torch.nn as nn
import torch.nn.functional as F

V_FAKE = (2, 3)       # classes with manipulated video
A_FAKE = (1, 3)       # classes with manipulated audio


# ====================================================================== Shapley machinery
def coalition_masks(n):
    """(2^n, n) bool, row r = binary expansion of r."""
    return torch.tensor(list(product([0, 1], repeat=n))[::1], dtype=torch.bool).flip(-1)


def shapley_matrix(n):
    """W (2^n, n) such that phi = v @ W for a value vector v over all coalitions (exact)."""
    M = coalition_masks(n)
    W = torch.zeros(2 ** n, n, dtype=torch.float64)
    fact = [math.factorial(k) for k in range(n + 1)]
    for r in range(2 ** n):
        s = int(M[r].sum())
        for i in range(n):
            if M[r, i]:          # S contains i: + weight(|S|-1)
                W[r, i] += fact[s - 1] * fact[n - s] / fact[n]
            else:                # S lacks i: - weight(|S|)
                W[r, i] -= fact[s] * fact[n - s - 1] / fact[n]
    return W


def group_logprob(logp, groups):
    """log P(class in groups) from 4-way log-probs."""
    return torch.logsumexp(logp[..., list(groups)], -1)


def marginal_nll(logp, y, groups):
    """NLL of the binary event 'y in groups' under the 4-way distribution."""
    lp_in = group_logprob(logp, groups)
    lp_out = torch.log1p(-lp_in.exp().clamp(max=1 - 1e-6))
    tgt = torch.zeros_like(y, dtype=torch.bool)
    for g in groups:
        tgt |= y == g
    return -torch.where(tgt, lp_in, lp_out)


class ShapleyFusion(nn.Module):
    """Players are 6 d-dim tokens: [V_syl, V_word, V_sent, A_syl, A_word, A_sent]."""
    def __init__(self, d, n_classes=4, alloc="proportional", value="info", hidden=256, p=0.1):
        super().__init__()
        self.n, self.C, self.alloc, self.value = 6, n_classes, alloc, value
        self.absent = nn.Parameter(torch.zeros(6, d))
        nn.init.normal_(self.absent, std=0.02)
        self.norm = nn.LayerNorm(d)
        self.vnet = nn.Sequential(nn.Linear(d + 3 + 3 + 6, hidden), nn.GELU(), nn.Dropout(p),
                                  nn.Linear(hidden, hidden), nn.GELU(), nn.Linear(hidden, n_classes))
        self.log_tau = nn.Parameter(torch.zeros(()))
        M = coalition_masks(6)
        self.register_buffer("masks", M)
        self.register_buffer("W", shapley_matrix(6).float())
        self.full = int((M.sum(1) == 6).nonzero()[0])
        self.v_only = int(((M[:, :3].all(1)) & (~M[:, 3:].any(1))).nonzero()[0])
        self.a_only = int(((M[:, 3:].all(1)) & (~M[:, :3].any(1))).nonzero()[0])
        self.empty = int((M.sum(1) == 0).nonzero()[0])

    def coalition_logits(self, T, s, sv, present):
        """T (B,6,d), s/sv (B,3), present (B,6) bool -> logits (B,64,C), effective masks (B,64,6)."""
        m = self.masks[None] & present[:, None]                                   # (B,64,6)
        mf = m.float()[..., None]
        h = self.norm((mf * T[:, None] + (1 - mf) * self.absent[None, None]).mean(2))   # (B,64,d)
        both = m[..., :3] & m[..., 3:]                                            # (B,64,3)
        s_eff = torch.where(both, s[:, None].expand_as(both.float()), torch.full_like(both, 0.5, dtype=s.dtype))
        sv_eff = both.to(sv.dtype) * sv[:, None]
        return self.vnet(torch.cat([h, s_eff, sv_eff, m.to(h.dtype)], -1)), m

    def forward(self, T, s, sv, present):
        logits, m = self.coalition_logits(T, s, sv, present)
        logp = F.log_softmax(logits.float(), -1)
        if self.value == "info":
            v = math.log(self.C) + (logp.exp() * logp).sum(-1)                  # log C - H
        else:                                                                  # 'conf': max log-prob
            v = logp.max(-1).values
        phi = v @ self.W                                                       # (B,6) exact Shapley
        pres = present.float()
        if self.alloc == "proportional":
            w = (F.relu(phi) + 1e-4) * pres
        elif self.alloc == "softmax":
            w = torch.exp(phi / self.log_tau.exp()) * pres
        else:                                                                  # 'uniform' (ablation)
            w = pres.clone()
        w = w / w.sum(-1, keepdim=True).clamp(min=1e-8)
        f = (w[..., None].to(T.dtype) * T).sum(1)
        return {"f": f, "w": w, "phi": phi, "v": v, "coal_logp": logp, "masks": m,
                "grand_logits": logits[:, self.full]}

    def coalition_losses(self, out, y):
        """Supervise every non-empty coalition with the event it can identify.
        Returns (L_coal over all coalitions, L_V on the full-visual coalition, L_A on the full-audio one)."""
        logp, m = out["coal_logp"], out["masks"]                              # (B,64,C), (B,64,6)
        hasV, hasA = m[..., :3].any(-1), m[..., 3:].any(-1)
        yy = y[:, None].expand(-1, logp.shape[1])
        nll_av = F.nll_loss(logp.reshape(-1, self.C), yy.reshape(-1), reduction="none").view_as(yy)
        nll_v = marginal_nll(logp, yy, V_FAKE)
        nll_a = marginal_nll(logp, yy, A_FAKE)
        nll = torch.where(hasV & hasA, nll_av, torch.where(hasV, nll_v, nll_a))
        ok = (hasV | hasA).float()
        L_coal = (nll * ok).sum() / ok.sum().clamp(min=1)
        return L_coal, nll_v[:, self.v_only].mean(), nll_a[:, self.a_only].mean()


# ====================================================================== Nash bargaining (Nash-MTL)
def nbs_weights(M, iters=50, eps=1e-10):
    """argmin_{alpha>0} 1/2 a^T M a - sum log a  ==  solution of M a = 1/a.  M (K,K) PSD, float64.
    Newton in log-space with backtracking; tasks with ~zero gradient get alpha = 0."""
    K = M.shape[0]
    diag = torch.diagonal(M)
    act = diag > eps * diag.max().clamp(min=eps)
    alpha = torch.zeros(K, dtype=M.dtype, device=M.device)
    if act.sum() == 0:
        return alpha
    Ma = M[act][:, act]
    b = -0.5 * torch.log(torch.diagonal(Ma))           # init: alpha_i = 1/sqrt(M_ii)
    f = lambda b: 0.5 * (b.exp() @ Ma @ b.exp()) - b.sum()
    for _ in range(iters):
        a = b.exp()
        g = a * (Ma @ a) - 1
        if g.abs().max() < 1e-9:
            break
        H = torch.diag(a * (Ma @ a)) + torch.outer(a, a) * Ma
        step = torch.linalg.solve(H + 1e-12 * torch.eye(len(b), dtype=M.dtype, device=M.device), g)
        t, f0 = 1.0, f(b)
        while f(b - t * step) > f0 - 1e-4 * t * (g @ step) and t > 1e-8:
            t *= 0.5
        b = b - t * step
    alpha[act] = b.exp()
    return alpha


class NashMTL:
    """Combine K task gradients by the Nash bargaining solution on shared parameters.
    Task-specific parameters (touched by one task only) receive their plain gradient."""
    def __init__(self, params, n_tasks):
        self.params = [p for p in params if p.requires_grad]
        self.K = n_tasks
        self.shared = None
        self.last_alpha = torch.ones(n_tasks)

    def backward(self, losses):
        grads = [torch.autograd.grad(L, self.params, retain_graph=(k < self.K - 1), allow_unused=True)
                 for k, L in enumerate(losses)]
        if self.shared is None:
            self.shared = [sum(g[i] is not None for g in grads) >= 2 for i in range(len(self.params))]
        G = torch.stack([torch.cat([(g[i] if g[i] is not None else torch.zeros_like(p)).flatten().float()
                                    for i, p in enumerate(self.params) if self.shared[i]]) for g in grads])
        alpha = nbs_weights((G @ G.T).double()).float()
        self.last_alpha = alpha.detach().cpu()
        for i, p in enumerate(self.params):
            parts = [(alpha[k] if self.shared[i] else 1.0) * grads[k][i]
                     for k in range(self.K) if grads[k][i] is not None]
            p.grad = sum(parts).to(p.dtype) if parts else None
        return self.last_alpha
