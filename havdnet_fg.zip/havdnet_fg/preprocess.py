"""
preprocess.py -- raw videos -> per-frame feature store. Replaces preprocess_full.py AND precache.py.

Two independent stages; `all` runs them concurrently so the GPUs and every CPU core stay busy:
  asr       WhisperX transcription + forced alignment on each GPU (A procs/GPU), ffmpeg audio
            extraction prefetched on threads; language-aware syllables -> align.json
  features  per GPU: one inference process fed by a pool of CPU workers that decode the video,
            run MediaPipe FaceLandmarker in VIDEO (tracking) mode once per frame, and build
            lip / face / ArcFace-aligned crops; the GPU process runs CLIP ViT-B/32, ArcFace r50 and
            XLSR-53 in batches and writes the store. Bounded prefetch -> constant memory.

Store, one folder per video  (store/<md5(path)>/):
  clip.npy      (T,512) fp16   CLIP face embedding of EVERY frame (0 where no face)
  arc.npy       (T,512) fp16   ArcFace embedding of every frame (5-point aligned from the mesh)
  face_ok.npy   (T,)    bool
  lips.bin + lips_off.npy      96x48 lip crops of every frame, JPEG bytes in one file + offsets
  xlsr.npy      (Ta,3,1024) fp16  XLSR-53 layer-group means (1-7 | 8-16 | 17-24), 40 ms hop
  align.json    words / syllables / transcript / language        (asr stage)
  meta.json     manifest row + video stats                       (features stage, written last)
Because features are stored per frame, word/syllable pooling happens in the DataLoader: the
timestamp-robustness experiments (jitter / offset / dropped words) need NO re-extraction.

Usage
  python preprocess.py all --manifest fav_manifest.csv --store /ws/store_fav           # every GPU, all cores
  python preprocess.py features --manifest m.csv --store S --gpus 0,1 --cpu_workers 30
  python preprocess.py asr --manifest m.csv --store S --asr_per_gpu 2
  # corrupted copies of the TEST split (realistic: the whole video is re-encoded first)
  python preprocess.py features --manifest m.csv --store /ws/store_fav_crf35 --crf 35 \
         --keys runs/fav/gt_s0/split.json:test --reuse_align /ws/store_fav
  python preprocess.py all --manifest m.csv --store /ws/store_fav_snr10 --snr 10 --keys runs/fav/gt_s0/split.json:test
  python preprocess.py status --store /ws/store_fav
"""
import argparse
import csv
import json
import os
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from collections import deque
from pathlib import Path

import numpy as np

from common import XLSR_LAYERS, video_key

SR = 16000
XLSR_POOL = 2                       # 2 x 20 ms = 40 ms hop (one row per 25-fps video frame)
LIP_LANDMARKS = [61, 185, 40, 39, 37, 0, 267, 269, 270, 409, 291, 308, 415, 310, 311, 312, 13, 82, 81, 80, 191, 78]
ARC_DST = np.array([[38.2946, 51.6963], [73.5318, 51.5014], [56.0252, 71.7366],
                    [41.5493, 92.3655], [70.7299, 92.2041]], dtype=np.float32)
CLIP_MEAN = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
CLIP_STD = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)
MESH_URL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task"
MESH_PATH = os.path.expanduser("~/.cache/mediapipe/face_landmarker.task")
LANG_CODE = {"English": "en", "French": "fr", "Spanish": "es", "Russian": "ru", "Chinese": "zh",
             "Arabic": "ar", "Japanese": "ja"}
PROMPTS = ["an authentic video of a real person speaking",
           "a real video of a person with a cloned synthetic voice",
           "a face-manipulated deepfake video with the person's real voice",
           "a face-manipulated deepfake video with a cloned synthetic voice"]


# ====================================================================== manifest / store helpers
def read_manifest(path, keys_spec=None, shard="0/1"):
    rows = list(csv.DictReader(open(path, newline="", encoding="utf-8")))
    for r in rows:
        r["key"] = video_key(r["path"])
    if keys_spec:
        f, part = keys_spec.rsplit(":", 1)
        keep = set(json.load(open(f))["splits"][part])
        rows = [r for r in rows if r["key"] in keep]
    si, sn = (int(x) for x in shard.split("/"))
    return [r for i, r in enumerate(rows) if i % sn == si]


def atomic_json(obj, path):
    tmp = Path(str(path) + ".tmp")
    json.dump(obj, open(tmp, "w"), indent=1)
    os.replace(tmp, path)


def features_done(d):
    return (d / "meta.json").exists()


def asr_done(d):
    return (d / "align.json").exists()


def add_noise(wav, snr_db, key):
    rng = np.random.default_rng(int(key[:8], 16))
    p = max(float(np.mean(wav ** 2)), 1e-10)
    return (wav + rng.standard_normal(wav.shape).astype(np.float32) * np.sqrt(p / 10 ** (snr_db / 10))).astype(np.float32)


def load_audio(path, key=None, snr=None):
    """ffmpeg -> 16 kHz mono float32 (no temp files)."""
    cmd = ["ffmpeg", "-nostdin", "-v", "error", "-i", str(path), "-vn", "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"]
    out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    wav = np.frombuffer(out.stdout, dtype=np.float32).copy()
    if snr is not None and wav.size:
        wav = add_noise(wav, snr, key)
    return wav


# ====================================================================== syllables (language-aware)
PYPHEN = {"en": "en_US", "fr": "fr", "es": "es", "ru": "ru_RU", "de": "de_DE", "it": "it_IT", "pt": "pt_PT"}
SMALL_KANA = set("ゃゅょぁぃぅぇぉっャュョァィゥェォッー")
_PYPHEN_CACHE = {}


def split_units(word, dur, lang):
    w = word.strip(".,!?;:\"'。、！？「」()[]")
    if not w:
        return [word or "_"]
    if lang == "zh":
        return [c for c in w if not c.isspace()] or [w]
    if lang == "ja":
        units = []
        for c in w:
            if c in SMALL_KANA and units:
                units[-1] += c
            else:
                units.append(c)
        return units or [w]
    if lang in PYPHEN:
        try:
            import pyphen
            if lang not in _PYPHEN_CACHE:
                _PYPHEN_CACHE[lang] = pyphen.Pyphen(lang=PYPHEN[lang])
            u = _PYPHEN_CACHE[lang].inserted(w.lower(), hyphen="|").split("|")
            return [x for x in u if x] or [w]
        except Exception:
            pass
    n = max(1, round(dur / 0.2))                         # Arabic and anything without a dictionary
    k = max(1, -(-len(w) // n))
    return [w[i:i + k] for i in range(0, len(w), k)] or [w]


def syllabify(words, lang):
    out = []
    for wd in words:
        dur = max(wd["end"] - wd["start"], 0.01)
        parts = split_units(wd["word"], dur, lang)
        lens = [max(len(p), 1) for p in parts]
        t = wd["start"]
        for i, (p, l) in enumerate(zip(parts, lens)):
            d = dur * l / sum(lens)
            out.append({"syllable": p, "word": wd["word"], "word_pos": f"{i + 1}/{len(parts)}",
                        "start": round(t, 4), "end": round(t + d, 4)})
            t += d
    return out


# ====================================================================== ASR stage
def asr_worker(gpu, slot, rows, store, a, status_q):
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu)
    tag = f"asr[g{gpu}.{slot}]"
    todo = [r for r in rows if not asr_done(store / r["key"])]
    if a.reuse_align:
        n = 0
        for r in todo:
            src = Path(a.reuse_align) / r["key"] / "align.json"
            if src.exists():
                (store / r["key"]).mkdir(parents=True, exist_ok=True)
                shutil.copy(src, store / r["key"] / "align.json"); n += 1
        todo = [r for r in todo if not asr_done(store / r["key"])]
        print(f"{tag} reused {n} alignments, {len(todo)} left", flush=True)
    if not todo:
        status_q.put((tag, 0, 0)); return
    if a.smoke_test:
        wx = None
    else:
        import whisperx
        wx = whisperx
        try:
            model = wx.load_model(a.asr_model, device="cuda", compute_type="float16")
        except Exception:
            print(f"{tag} {a.asr_model} unavailable, falling back to large-v3", flush=True)
            model = wx.load_model("large-v3", device="cuda", compute_type="float16")
        aligners = {}
    from concurrent.futures import ThreadPoolExecutor
    pool = ThreadPoolExecutor(max(2, a.asr_io_threads))
    futs = deque(pool.submit(load_audio, r["path"], r["key"], a.snr) for r in todo[:8])
    nxt, ok, fail, t0 = 8, 0, 0, time.time()
    for i, r in enumerate(todo):
        wav = futs.popleft().result()
        if nxt < len(todo):
            futs.append(pool.submit(load_audio, todo[nxt]["path"], todo[nxt]["key"], a.snr)); nxt += 1
        d = store / r["key"]
        d.mkdir(parents=True, exist_ok=True)
        try:
            lang = r.get("lang_code") or LANG_CODE.get(r.get("language", ""), "") or None
            if wav.size < SR * 0.3:
                raise RuntimeError("audio too short / missing")
            if wx is None:                                  # smoke: evenly spaced pseudo-words
                dur = wav.size / SR
                words = [{"word": "w", "start": round(t, 3), "end": round(min(t + 0.3, dur), 3)}
                         for t in np.arange(0.2, max(dur - 0.4, 0.3), 0.45)]
                lang = lang or "en"
            else:
                res = model.transcribe(wav, batch_size=a.asr_batch, language=lang)
                lang = lang or res.get("language", "en")
                if lang not in aligners:
                    try:
                        aligners[lang] = wx.load_align_model(language_code=lang, device="cuda")
                    except Exception:
                        aligners[lang] = None
                if aligners[lang] is None:
                    raise RuntimeError(f"no alignment model for language '{lang}'")
                am, meta = aligners[lang]
                al = wx.align(res["segments"], am, meta, wav, device="cuda", return_char_alignments=False)
                words = [{"word": s.get("word", "").strip(), "start": round(float(s["start"]), 4),
                          "end": round(float(s["end"]), 4)}
                         for s in al.get("word_segments", []) if "start" in s and "end" in s and s["end"] > s["start"]]
            atomic_json({"words": words, "syllables": syllabify(words, lang), "language": lang,
                         "transcript": " ".join(w["word"] for w in words), "asr_model": a.asr_model,
                         "audio_sec": round(wav.size / SR, 3), "snr": a.snr}, d / "align.json")
            (d / "asr_error.txt").unlink(missing_ok=True)
            ok += 1
        except Exception as e:
            fail += 1
            (d / "asr_error.txt").write_text(f"{type(e).__name__}: {e}\n")
        if (i + 1) % 50 == 0:
            rate = (i + 1) / (time.time() - t0)
            print(f"{tag} {i + 1}/{len(todo)}  {rate:.2f} vid/s  eta {(len(todo) - i - 1) / rate / 60:.1f} min", flush=True)
    pool.shutdown()
    status_q.put((tag, ok, fail))


# ====================================================================== features: CPU side
_MESH = {}


def cpu_init(smoke):
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    import cv2
    cv2.setNumThreads(1)
    _MESH["smoke"] = smoke


def new_landmarker():
    from mediapipe.tasks import python as mpt
    from mediapipe.tasks.python import vision as mpv
    opts = mpv.FaceLandmarkerOptions(base_options=mpt.BaseOptions(model_asset_path=MESH_PATH),
                                     running_mode=mpv.RunningMode.VIDEO, num_faces=1,
                                     min_face_detection_confidence=0.4, min_face_presence_confidence=0.4,
                                     min_tracking_confidence=0.4)
    return mpv.FaceLandmarker.create_from_options(opts)


def similarity(src, dst):
    """Least-squares similarity transform (Umeyama) src->dst, 2x3."""
    sm, dm = src.mean(0), dst.mean(0)
    s, d = src - sm, dst - dm
    U, S, Vt = np.linalg.svd(d.T @ s / len(src))
    D = np.eye(2)
    if np.linalg.det(U) * np.linalg.det(Vt) < 0:
        D[1, 1] = -1
    R = U @ D @ Vt
    scale = np.trace(np.diag(S) @ D) / s.var(0).sum()
    M = np.zeros((2, 3), dtype=np.float32)
    M[:, :2] = scale * R
    M[:, 2] = dm - scale * R @ sm
    return M


def transcode(path, crf, scale, tmpdir):
    """Re-encode the whole video (H.264 CRF and/or down-up scaling) -> temp mp4."""
    import cv2
    cap = cv2.VideoCapture(str(path)); W, H = int(cap.get(3)), int(cap.get(4)); cap.release()
    vf = []
    if scale and scale < 1:
        vf += [f"scale={max(2, int(W * scale) // 2 * 2)}:{max(2, int(H * scale) // 2 * 2)}", f"scale={W}:{H}"]
    out = Path(tmpdir) / (Path(path).stem + "_t.mp4")
    cmd = ["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", str(path)] + (["-vf", ",".join(vf)] if vf else []) + \
          ["-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf if crf is not None else 18), "-an", "-threads", "1", str(out)]
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    return out


def cpu_stage(job):
    """Decode + landmarks + crops for one video. Returns arrays for the GPU process."""
    import cv2
    r, opt = job
    t0 = time.time()
    try:
        src, tmpdir = r["path"], None
        if opt["crf"] is not None or opt["scale"]:
            tmpdir = tempfile.mkdtemp(dir="/dev/shm" if os.path.isdir("/dev/shm") else None)
            src = transcode(r["path"], opt["crf"], opt["scale"], tmpdir)
        cap = cv2.VideoCapture(str(src))
        fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
        if not (1 < fps < 121):
            fps = 25.0
        lm = None if _MESH.get("smoke") else new_landmarker()
        mp_ = None if _MESH.get("smoke") else __import__("mediapipe")
        lips, ok, faces, arcs, t = [], [], [], [], 0
        enc = [int(cv2.IMWRITE_JPEG_QUALITY), 92]
        while True:
            got, bgr = cap.read()
            if not got:
                break
            h, w = bgr.shape[:2]
            rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
            if lm is None:                                  # smoke: fixed central "face"
                pts = np.array([[w * (0.35 + 0.3 * ((i * 37) % 100) / 100), h * (0.3 + 0.45 * ((i * 61) % 100) / 100)]
                                for i in range(468)], dtype=np.float32)
                pts[LIP_LANDMARKS] = [[w * (0.42 + 0.16 * (i % 11) / 10), h * (0.62 + 0.06 * (i // 11))] for i in range(22)]
            else:
                sc = min(1.0, opt["mesh_max_side"] / max(h, w))
                small = rgb if sc == 1.0 else cv2.resize(rgb, (int(w * sc), int(h * sc)), interpolation=cv2.INTER_AREA)
                res = lm.detect_for_video(mp_.Image(image_format=mp_.ImageFormat.SRGB, data=np.ascontiguousarray(small)),
                                          int(round(t * 1000 / fps)))
                pts = None
                if res.face_landmarks:
                    pts = np.array([(p.x * w, p.y * h) for p in res.face_landmarks[0][:468]], dtype=np.float32)
            good = False
            if pts is not None:
                lp = pts[LIP_LANDMARKS]
                x1, y1 = np.maximum(lp.min(0) - 8, 0).astype(int)
                x2, y2 = np.minimum(lp.max(0) + 8, [w, h]).astype(int)
                fx1, fy1 = np.maximum(pts.min(0) - 30, 0).astype(int)
                fx2, fy2 = np.minimum(pts.max(0) + 30, [w, h]).astype(int)
                if x2 > x1 + 4 and y2 > y1 + 2 and fx2 > fx1 + 8 and fy2 > fy1 + 8:
                    lips.append(cv2.imencode(".jpg", cv2.resize(bgr[y1:y2, x1:x2], (96, 48), interpolation=cv2.INTER_AREA), enc)[1].tobytes())
                    faces.append(cv2.resize(rgb[fy1:fy2, fx1:fx2], (224, 224), interpolation=cv2.INTER_AREA))
                    kps = np.stack([pts[[33, 133]].mean(0), pts[[362, 263]].mean(0), pts[1], pts[61], pts[291]])
                    arcs.append(cv2.warpAffine(bgr, similarity(kps, ARC_DST), (112, 112), borderValue=0))
                    good = True
            if not good:
                lips.append(b"")
            ok.append(good)
            t += 1
        cap.release()
        if t == 0:
            raise RuntimeError(f"no frames decoded from {src}")
        if lm is not None:
            lm.close()
        if tmpdir:
            shutil.rmtree(tmpdir, ignore_errors=True)
        wav = load_audio(r["path"], r["key"], opt["snr"])
        return {"row": r, "fps": fps, "lips": lips, "ok": np.array(ok, dtype=bool),
                "faces": np.stack(faces) if faces else np.zeros((0, 224, 224, 3), np.uint8),
                "arcs": np.stack(arcs) if arcs else np.zeros((0, 112, 112, 3), np.uint8),
                "wav": wav, "cpu_sec": time.time() - t0, "err": None}
    except Exception:
        return {"row": r, "err": traceback.format_exc()}


# ====================================================================== features: GPU side
class GPUModels:
    def __init__(self, gpu, smoke):
        import torch
        self.torch, self.smoke = torch, smoke
        self.dev = "cuda:0" if torch.cuda.is_available() else "cpu"
        if smoke:
            g = torch.Generator().manual_seed(0)
            self.Wc = torch.randn(3 * 8 * 8, 512, generator=g)
            self.Wa = torch.randn(3 * 8 * 8, 512, generator=g)
            self.Wx = torch.randn(201, 1024, generator=g) / 14
            return
        import clip
        from insightface.app import FaceAnalysis
        from transformers import Wav2Vec2Model
        self.clip, _ = clip.load("ViT-B/32", device=self.dev)
        self.clip.eval()
        self.mean = torch.tensor(CLIP_MEAN, device=self.dev).view(1, 3, 1, 1)
        self.std = torch.tensor(CLIP_STD, device=self.dev).view(1, 3, 1, 1)
        fa = FaceAnalysis(name="buffalo_l", allowed_modules=["detection", "recognition"],   # FaceAnalysis requires a detector
                          providers=[("CUDAExecutionProvider", {"device_id": 0}), "CPUExecutionProvider"])
        fa.prepare(ctx_id=0)
        self.arc = fa.models["recognition"]
        prov = self.arc.session.get_providers()
        if "CUDAExecutionProvider" not in prov:
            print(f"!! ArcFace is running on {prov} -- install an onnxruntime-gpu build matching your CUDA, "
                  "otherwise it steals CPU from the landmark workers", flush=True)
        self.xlsr = Wav2Vec2Model.from_pretrained("facebook/wav2vec2-large-xlsr-53").to(self.dev).half().eval()

    def clip_feats(self, faces, bs=512):
        torch = self.torch
        if len(faces) == 0:
            return np.zeros((0, 512), np.float16)
        if self.smoke:
            x = torch.from_numpy(faces[:, ::28, ::28].reshape(len(faces), -1).astype(np.float32) / 255)
            return torch.nn.functional.normalize(x @ self.Wc, dim=-1).half().numpy()
        out = []
        with torch.inference_mode():
            for i in range(0, len(faces), bs):
                x = torch.from_numpy(faces[i:i + bs]).to(self.dev, non_blocking=True).permute(0, 3, 1, 2).float().div_(255)
                e = self.clip.encode_image(((x - self.mean) / self.std).half())
                out.append(torch.nn.functional.normalize(e.float(), dim=-1).half().cpu())
        return torch.cat(out).numpy()

    def arc_feats(self, arcs, bs=256):
        if len(arcs) == 0:
            return np.zeros((0, 512), np.float16)
        if self.smoke:
            x = self.torch.from_numpy(arcs[:, ::14, ::14].reshape(len(arcs), -1).astype(np.float32) / 255)
            return self.torch.nn.functional.normalize(x @ self.Wa, dim=-1).half().numpy()
        out = [self.arc.get_feat(list(arcs[i:i + bs])) for i in range(0, len(arcs), bs)]
        f = np.concatenate(out).astype(np.float32)
        return (f / np.linalg.norm(f, axis=1, keepdims=True).clip(1e-6)).astype(np.float16)

    def xlsr_feats(self, wav, chunk_sec=30):
        torch = self.torch
        if self.smoke:
            spec = torch.stft(torch.from_numpy(wav), 400, 320, window=torch.hann_window(400), return_complex=True).abs().T
            f = torch.log1p(spec) @ self.Wx
            g = torch.stack([f, f.roll(1, 1), f.roll(2, 1)], 1)
        else:
            x = torch.from_numpy((wav - wav.mean()) / (wav.std() + 1e-7))
            parts = []
            with torch.inference_mode():
                for s in range(0, len(x), chunk_sec * SR):
                    seg = x[s:s + chunk_sec * SR]
                    if len(seg) < 400:
                        continue
                    hs = self.xlsr(seg[None].to(self.dev).half(), output_hidden_states=True).hidden_states
                    parts.append(torch.stack([torch.stack(hs[a:b + 1]).mean(0)[0] for a, b in XLSR_LAYERS.values()], 1).float().cpu())
            g = torch.cat(parts) if parts else torch.zeros(0, 3, 1024)
        T = g.shape[0] // XLSR_POOL * XLSR_POOL
        g = g[:T].view(-1, XLSR_POOL, 3, 1024).mean(1) if T else g[:0]
        return g.half().numpy()


def write_store(d, res, m, opt):
    d.mkdir(parents=True, exist_ok=True)
    ok = res["ok"]
    T = len(ok)
    clip_full = np.zeros((T, 512), np.float16); arc_full = np.zeros((T, 512), np.float16)
    clip_full[ok] = m.clip_feats(res["faces"]); arc_full[ok] = m.arc_feats(res["arcs"])
    xl = m.xlsr_feats(res["wav"])
    np.save(d / "clip.npy", clip_full); np.save(d / "arc.npy", arc_full); np.save(d / "face_ok.npy", ok)
    np.save(d / "xlsr.npy", xl)
    offs = np.zeros(T + 1, dtype=np.int64)
    np.cumsum([len(b) for b in res["lips"]], out=offs[1:])
    with open(d / "lips.bin", "wb") as f:
        for b in res["lips"]:
            f.write(b)
    np.save(d / "lips_off.npy", offs)
    r = {k: v for k, v in res["row"].items()}
    meta = {**r, "key": r["key"], "rel": r["path"], "label": int(r["label"]), "fps": res["fps"], "n_frames": T,
            "duration_sec": round(T / res["fps"], 3), "audio_sec": round(len(res["wav"]) / SR, 3),
            "xlsr_hz": SR / 320 / XLSR_POOL, "n_xlsr": int(xl.shape[0]), "face_ok_frac": float(ok.mean()) if T else 0.0,
            "corrupt": {k: opt[k] for k in ("crf", "scale", "snr") if opt[k] is not None} or None,
            "smoke_test": opt["smoke"], "store_version": 3}
    atomic_json(meta, d / "meta.json")
    return meta


def feature_worker(gpu, n_cpu, rows, store, a, status_q):
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu)
    import multiprocessing as mp
    tag = f"feat[g{gpu}]"
    todo = [r for r in rows if not features_done(store / r["key"])]
    if not todo:
        status_q.put((tag, 0, 0)); return
    m = GPUModels(gpu, a.smoke_test)
    opt = {"crf": a.crf, "scale": a.scale, "snr": a.snr, "mesh_max_side": a.mesh_max_side, "smoke": a.smoke_test}
    ctx = mp.get_context("spawn")
    for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
        os.environ[v] = "1"                                 # inherited by the CPU workers: one core each
    pool = ctx.Pool(n_cpu, initializer=cpu_init, initargs=(a.smoke_test,), maxtasksperchild=200)
    pending, it = deque(), iter(todo)
    for r in it:                                            # bounded prefetch: 2 jobs per CPU worker
        pending.append(pool.apply_async(cpu_stage, ((r, opt),)))
        if len(pending) >= 2 * n_cpu:
            break
    ok = fail = done = 0
    t0, gpu_sec, cpu_sec = time.time(), 0.0, 0.0
    while pending:
        idx = next((i for i, p in enumerate(pending) if p.ready()), None)
        res = (pending[idx] if idx is not None else pending[0]).get()
        del pending[idx if idx is not None else 0]
        nxt = next(it, None)
        if nxt is not None:
            pending.append(pool.apply_async(cpu_stage, ((nxt, opt),)))
        d = store / res["row"]["key"]
        if res["err"]:
            fail += 1
            d.mkdir(parents=True, exist_ok=True)
            (d / "feat_error.txt").write_text(res["err"])
        else:
            tg = time.time()
            try:
                meta = write_store(d, res, m, opt)
                (d / "feat_error.txt").unlink(missing_ok=True)
                ok += 1
                if meta["face_ok_frac"] < 0.5:
                    print(f"{tag} [warn] {meta['key']} face found in {meta['face_ok_frac']:.0%} of frames", flush=True)
            except Exception:
                fail += 1
                (d / "feat_error.txt").write_text(traceback.format_exc())
            gpu_sec += time.time() - tg
            cpu_sec += res["cpu_sec"]
        done += 1
        if done % 50 == 0:
            el = time.time() - t0
            print(f"{tag} {done}/{len(todo)}  {done / el:.2f} vid/s  eta {(len(todo) - done) / (done / el) / 60:.1f} min  "
                  f"| gpu busy {gpu_sec / el:.0%}  cpu-sec/vid {cpu_sec / max(ok, 1):.1f}", flush=True)
    pool.close(); pool.join()
    status_q.put((tag, ok, fail))


# ====================================================================== orchestration
def prefetch_models(a, need_feat, need_asr):
    """Download every model once, sequentially, before workers start (avoids download races)."""
    if a.smoke_test:
        return
    if need_feat:
        if not os.path.exists(MESH_PATH):
            os.makedirs(os.path.dirname(MESH_PATH), exist_ok=True)
            import urllib.request
            print(f"downloading {MESH_URL}")
            urllib.request.urlretrieve(MESH_URL, MESH_PATH)
        import clip
        clip.load("ViT-B/32", device="cpu")
        from transformers import Wav2Vec2Model
        Wav2Vec2Model.from_pretrained("facebook/wav2vec2-large-xlsr-53")
        from insightface.app import FaceAnalysis
        FaceAnalysis(name="buffalo_l", allowed_modules=["detection", "recognition"], providers=["CPUExecutionProvider"])
    if need_asr:
        import whisperx
        try:
            whisperx.load_model(a.asr_model, device="cpu", compute_type="int8")
        except Exception:
            whisperx.load_model("large-v3", device="cpu", compute_type="int8")


def write_prompts(store, smoke):
    if (store / "prompts.pt").exists():
        return
    import torch
    if smoke:
        emb = torch.nn.functional.normalize(torch.randn(4, 512), dim=-1)
    else:
        import clip
        m, _ = clip.load("ViT-B/32", device="cpu")
        with torch.no_grad():
            emb = torch.nn.functional.normalize(m.encode_text(clip.tokenize(PROMPTS)).float(), dim=-1)
    from common import CLASS_NAMES
    torch.save({"names": CLASS_NAMES, "emb": emb}, store / "prompts.pt")


def detect_gpus(spec):
    if spec:
        return [int(g) for g in spec.split(",")]
    try:
        import torch
        n = torch.cuda.device_count()
    except Exception:
        n = 0
    return list(range(n)) or [0]


def run(a, stages):
    store = Path(a.store); store.mkdir(parents=True, exist_ok=True)
    rows = read_manifest(a.manifest, a.keys, a.shard)
    gpus = detect_gpus(a.gpus)
    ncpu = a.cpu_workers or max(1, (os.cpu_count() or 2) - len(gpus) * (1 + (a.asr_per_gpu if "asr" in stages else 0)) - 1)
    print(f"videos: {len(rows)}  gpus: {gpus}  cpu workers: {ncpu}  stages: {stages}", flush=True)
    if a.reuse_align:                                       # video-only corruption: alignment is unchanged
        n = 0
        for r in rows:
            src, dst = Path(a.reuse_align) / r["key"] / "align.json", store / r["key"] / "align.json"
            if src.exists() and not dst.exists():
                dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy(src, dst); n += 1
        print(f"copied {n} alignments from {a.reuse_align}")
        stages = [s for s in stages if s != "asr" or any(not asr_done(store / r["key"]) for r in rows)]
    prefetch_models(a, "features" in stages, "asr" in stages)
    write_prompts(store, a.smoke_test)
    import multiprocessing as mp
    ctx = mp.get_context("spawn")
    q = ctx.Queue()
    procs = []
    if "features" in stages:
        per = [rows[i::len(gpus)] for i in range(len(gpus))]
        cpus = [ncpu // len(gpus) + (1 if i < ncpu % len(gpus) else 0) for i in range(len(gpus))]
        for g, rs, c in zip(gpus, per, cpus):
            procs.append(ctx.Process(target=feature_worker, args=(g, max(1, c), rs, store, a, q), daemon=False))
    if "asr" in stages:
        slots = [(g, s) for g in gpus for s in range(a.asr_per_gpu)]
        for j, (g, s) in enumerate(slots):
            procs.append(ctx.Process(target=asr_worker, args=(g, s, rows[j::len(slots)], store, a, q), daemon=False))
    for p in procs:
        p.start()
    for p in procs:
        p.join()
    res = []
    while not q.empty():
        res.append(q.get())
    for tag, ok, fail in sorted(res):
        print(f"  {tag}: ok={ok} failed={fail}")
    status(store, rows)


def status(store, rows=None):
    store = Path(store)
    dirs = [store / r["key"] for r in rows] if rows else [p for p in store.iterdir() if p.is_dir()]
    f = sum(features_done(d) for d in dirs); s = sum(asr_done(d) for d in dirs)
    both = sum(features_done(d) and asr_done(d) for d in dirs)
    fe = sum((d / "feat_error.txt").exists() and not features_done(d) for d in dirs)
    ae = sum((d / "asr_error.txt").exists() and not asr_done(d) for d in dirs)
    print(f"store {store}: {len(dirs)} videos | features {f} (errors {fe}) | alignment {s} (errors {ae}) | usable {both}")
    if fe or ae:
        print("  see <store>/<key>/feat_error.txt / asr_error.txt; re-running resumes and retries failures")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("stage", choices=["all", "features", "asr", "status"])
    ap.add_argument("--manifest")
    ap.add_argument("--store", required=True)
    ap.add_argument("--gpus", default=None, help="e.g. 0,1 (default: all visible)")
    ap.add_argument("--cpu_workers", type=int, default=0, help="decode/landmark workers (default: all free cores)")
    ap.add_argument("--asr_per_gpu", type=int, default=1)
    ap.add_argument("--asr_model", default="large-v3-turbo")
    ap.add_argument("--asr_batch", type=int, default=16)
    ap.add_argument("--asr_io_threads", type=int, default=4)
    ap.add_argument("--mesh_max_side", type=int, default=640, help="landmarks on a downscaled copy; crops use full res")
    ap.add_argument("--keys", default=None, help="split.json:test -> only those videos")
    ap.add_argument("--shard", default="0/1", help="i/n across machines")
    ap.add_argument("--crf", type=int, default=None, help="re-encode video with H.264 at this CRF")
    ap.add_argument("--scale", type=float, default=None, help="down/up-scale video by this factor")
    ap.add_argument("--snr", type=float, default=None, help="add white noise to audio at this SNR (dB)")
    ap.add_argument("--reuse_align", default=None, help="copy align.json from this store (video-only corruptions)")
    ap.add_argument("--smoke_test", action="store_true", help="stub models (plumbing tests only)")
    a = ap.parse_args()
    if a.stage == "status":
        status(a.store); return
    if not a.manifest:
        ap.error("--manifest is required")
    stages = {"all": ["features", "asr"], "features": ["features"], "asr": ["asr"]}[a.stage]
    run(a, stages)


if __name__ == "__main__":
    main()
