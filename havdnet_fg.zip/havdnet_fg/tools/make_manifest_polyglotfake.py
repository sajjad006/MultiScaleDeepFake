"""
make_manifest_polyglotfake.py -- build a manifest CSV for PolyGlotFake (or any dataset laid out by folders).

PolyGlotFake's archive layout / metadata format is not documented publicly, so labels are inferred from
path tokens and (optionally) merged from a metadata file. ALWAYS run --inspect first and check the
printed examples, label counts and grouping before preprocessing.

  python tools/make_manifest_polyglotfake.py --root /ws/PolyGlotFake --inspect
  python tools/make_manifest_polyglotfake.py --root /ws/PolyGlotFake --out pgf_manifest.csv \
         [--meta /ws/PolyGlotFake/<metadata>.csv] [--group_regex '^([^_]+)']

GROUPING (leakage-critical): every fake is a translation of a real source clip. Train/test must be split
by SOURCE clip, otherwise the same face/background appears on both sides. --group_regex extracts the
source-clip id from the file stem (first capture group); if a --meta file has a source/original column
it is used instead. The report prints how many fakes share a group id with a real video: if that number
is ~0 your regex is not capturing the link between a fake and its source -- fix it before training.
"""
import argparse
import csv
import re
from collections import Counter
from pathlib import Path

LANGS = {"english": "English", "en": "English", "french": "French", "fr": "French", "spanish": "Spanish",
         "es": "Spanish", "russian": "Russian", "ru": "Russian", "chinese": "Chinese", "zh": "Chinese",
         "cn": "Chinese", "mandarin": "Chinese", "arabic": "Arabic", "ar": "Arabic", "japanese": "Japanese",
         "ja": "Japanese", "jp": "Japanese"}
LANG_CODE = {"English": "en", "French": "fr", "Spanish": "es", "Russian": "ru", "Chinese": "zh",
             "Arabic": "ar", "Japanese": "ja"}
AUDIO_M = {"vallex": "vallex", "valle": "vallex", "xtts": "xtts", "microtts": "microtts",
           "tacotron": "tacotron", "bark": "bark", "freevc": "freevc"}
VIDEO_M = {"videoretalking": "videoretalking", "retalking": "videoretalking", "wav2lip": "wav2lip"}
REAL_T = {"real", "original", "originals", "raw", "source", "genuine", "pristine"}
FAKE_T = {"fake", "fakes", "manipulated", "deepfake", "synthetic", "forged"}
CATS = ["RealVideo-RealAudio", "RealVideo-FakeAudio", "FakeVideo-RealAudio", "FakeVideo-FakeAudio"]
VIDEO_EXT = {".mp4", ".avi", ".mov", ".mkv", ".webm"}


def tokens(path):
    return [t for t in re.split(r"[\\/_\-\.\s]+", str(path).lower()) if t]


def flat(path):
    return re.sub(r"[^a-z0-9]", "", str(path).lower())


def load_meta(path):
    """Generic metadata reader: csv/tsv/json/xlsx -> {stem: row}. Column names are lower-cased."""
    p = Path(path)
    rows = []
    if p.suffix in (".csv", ".tsv", ".txt"):
        with open(p, newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f, delimiter="\t" if p.suffix == ".tsv" else ","))
    elif p.suffix == ".json":
        import json
        d = json.load(open(p))
        rows = d if isinstance(d, list) else [dict(v, file=k) for k, v in d.items()]
    elif p.suffix in (".xlsx", ".xls"):
        import pandas as pd
        rows = pd.read_excel(p).astype(str).to_dict("records")
    out = {}
    for r in rows:
        r = {str(k).strip().lower(): str(v).strip() for k, v in r.items()}
        key = next((r[c] for c in ("path", "file", "filename", "video", "name", "video_name", "id") if r.get(c)), None)
        if key:
            out[Path(key).stem] = r
    print(f"[meta] {len(out)} rows, columns: {sorted(next(iter(out.values())).keys()) if out else []}")
    return out


def infer(path, root, meta_row, group_re):
    rel = path.relative_to(root)
    tk, fl = set(tokens(rel)), flat(rel)
    m = meta_row or {}
    mflat = flat(" ".join(m.values()))
    am = sorted({v for k, v in AUDIO_M.items() if k in fl or k in mflat})
    vm = sorted({v for k, v in VIDEO_M.items() if k in fl or k in mflat})
    lab_str = (m.get("label") or m.get("type") or m.get("class") or "").lower()
    is_real = (lab_str in ("real", "0", "original") or (tk & REAL_T and not tk & FAKE_T)) and not (am or vm)
    if lab_str in ("fake", "1"):
        is_real = False
    if is_real:
        label = 0
    elif am and vm:
        label = 3
    elif am:
        label = 1
    elif vm:
        label = 2
    else:
        label = 3                                          # PolyGlotFake fakes manipulate both modalities
    langs = [LANGS[t] for t in tokens(rel) if t in LANGS]
    lang_m = m.get("language") or m.get("lang") or m.get("target_language") or ""
    lang = LANGS.get(lang_m.lower(), lang_m) if lang_m else (langs[-1] if langs else "unknown")
    src_lang = m.get("source_language") or m.get("src_lang") or (langs[0] if len(langs) > 1 else "")
    src_lang = LANGS.get(src_lang.lower(), src_lang)
    grp = m.get("source") or m.get("original") or m.get("source_video") or m.get("src") or ""
    if not grp:
        mm = re.search(group_re, path.stem)
        grp = mm.group(1) if mm else path.stem
    return {"path": str(path), "label": label, "label_str": CATS[label], "identity": f"pgf_{grp}",
            "group": f"pgf_{grp}", "language": lang, "source_language": src_lang if label else lang,
            "method": "+".join(am + vm) if label else "real", "audio_method": "+".join(am),
            "video_method": "+".join(vm), "gender": m.get("gender", "unknown"), "age": m.get("age", ""),
            "lang_code": LANG_CODE.get(lang, ""), "dataset": "polyglotfake",
            "unknown_method": int(label != 0 and not (am or vm)), "method_from_csv": int(bool(am or vm))}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", required=True)
    ap.add_argument("--out", default="pgf_manifest.csv")
    ap.add_argument("--meta", default=None)
    ap.add_argument("--group_regex", default=r"^([A-Za-z0-9]+)")
    ap.add_argument("--inspect", action="store_true")
    a = ap.parse_args()
    root = Path(a.root).resolve()
    vids = sorted(p for p in root.rglob("*") if p.suffix.lower() in VIDEO_EXT)
    if not vids:
        raise SystemExit(f"no videos under {root}")
    meta = load_meta(a.meta) if a.meta else {}
    rows = [infer(p, root, meta.get(p.stem), a.group_regex) for p in vids]
    c = Counter(r["label_str"] for r in rows)
    real_groups = {r["group"] for r in rows if r["label"] == 0}
    linked = sum(1 for r in rows if r["label"] and r["group"] in real_groups)
    print(f"videos: {len(rows)}  labels: {dict(c)}")
    print(f"languages: {dict(Counter(r['language'] for r in rows))}")
    print(f"methods: {dict(Counter(r['method'] for r in rows).most_common(15))}")
    print(f"fakes with unrecognised method: {sum(r['unknown_method'] for r in rows)}")
    print(f"groups: {len({r['group'] for r in rows})}  real groups: {len(real_groups)}  "
          f"fakes linked to a real group: {linked}/{sum(1 for r in rows if r['label'])}")
    if linked == 0:
        print("!! no fake shares a group id with a real clip -- check --group_regex / --meta before splitting")
    if a.inspect:
        for lab in sorted(c):
            ex = [r for r in rows if r["label_str"] == lab][:8]
            print(f"\n--- {lab} examples (path -> group, language, method)")
            for r in ex:
                print(f"  {Path(r['path']).relative_to(root)} -> {r['group']}, {r['language']}, {r['method']}")
        return
    with open(a.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
