"""
make_manifest_fakeavceleb.py -- FakeAVCeleb_v1.2 folder + meta_data.csv -> manifest CSV for preprocess.py

  python tools/make_manifest_fakeavceleb.py --root /ws/FakeAVCeleb_v1.2 --out fav_manifest.csv

Layout: <root>/<Category>/<Ethnicity>/<gender>/<identity>/<video>.mp4. Real-video stems (00001.mp4 ...)
repeat across identities, so CSV rows are matched on (category, identity, stem), not the stem alone.
"""
import argparse
import csv
from collections import Counter, defaultdict
from pathlib import Path

CATS = ["RealVideo-RealAudio", "RealVideo-FakeAudio", "FakeVideo-RealAudio", "FakeVideo-FakeAudio"]
EXT = {".mp4", ".avi", ".mov", ".mkv"}


def load_csv(path):
    by_stem = defaultdict(list)
    with open(path, newline="", encoding="utf-8") as f:
        rd = csv.reader(f)
        hdr = [h.strip().lower() for h in next(rd)]
        for vals in rd:
            row = {(hdr[i] if i < len(hdr) and hdr[i] else f"col{i}"): v.strip() for i, v in enumerate(vals)}
            blob = " ".join(row.values()).replace("\\", "/")
            fname = row.get("path") or row.get("filename") or ""
            if not fname:
                continue
            row["_blob"] = blob
            by_stem[Path(fname).stem].append(row)
    return by_stem


def match(rows, cat, ident):
    if not rows:
        return {}
    if len(rows) == 1:
        return rows[0]
    hit = [r for r in rows if f"/{cat}/" in r["_blob"] + "/" or cat in r["_blob"]]
    hit = [r for r in hit if ident in r["_blob"]] or hit
    return hit[0] if len(hit) == 1 else {}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", required=True)
    ap.add_argument("--csv", default=None, help="default: <root>/meta_data.csv")
    ap.add_argument("--out", default="fav_manifest.csv")
    a = ap.parse_args()
    root = Path(a.root).resolve()
    csv_path = Path(a.csv) if a.csv else root / "meta_data.csv"
    meta = load_csv(csv_path) if csv_path.exists() else {}
    if not meta:
        print(f"[WARN] {csv_path} not found/empty: generator labels unavailable (generator head + unseen-generator runs disabled)")
    rows, miss = [], 0
    for lab, cat in enumerate(CATS):
        for p in sorted((root / cat).rglob("*")):
            if p.suffix.lower() not in EXT:
                continue
            parts = p.relative_to(root / cat).parts
            eth, gen, ident = (parts + ("unknown",) * 3)[:3] if len(parts) >= 4 else ("unknown", "unknown", p.parent.name)
            m = match(meta.get(p.stem, []), cat, ident)
            miss += bool(meta) and not m
            rows.append({"path": str(p), "label": lab, "label_str": cat, "identity": ident, "group": ident,
                         "ethnicity": eth, "gender": gen, "language": "English", "lang_code": "en",
                         "dataset": "fakeavceleb", "method": m.get("method", "real" if lab == 0 else ""),
                         "method_from_csv": int(bool(m.get("method"))), "source": m.get("source", ""),
                         "target1": m.get("target1", "-"), "target2": m.get("target2", "-"), "csv_type": m.get("type", "")})
    if not rows:
        raise SystemExit(f"no videos under {root}/<Category>/...")
    with open(a.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    print(f"videos: {len(rows)}  {dict(Counter(r['label_str'] for r in rows))}")
    print(f"methods: {dict(Counter(r['method'] for r in rows).most_common(12))}")
    print(f"unmatched in CSV: {miss}  identities: {len({r['identity'] for r in rows})}  -> {a.out}")


if __name__ == "__main__":
    main()
