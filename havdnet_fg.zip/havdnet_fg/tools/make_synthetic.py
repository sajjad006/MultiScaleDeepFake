"""Synthetic RAW videos + manifests, for plumbing tests of the whole pipeline (preprocess.py --smoke_test).
  python tools/make_synthetic.py /tmp/synth       -> /tmp/synth/{fav,pgf}_manifest.csv + mp4 files
Fake video = brighter mouth region; fake audio = higher pitch."""
import csv
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np

CATS = ["RealVideo-RealAudio", "RealVideo-FakeAudio", "FakeVideo-RealAudio", "FakeVideo-FakeAudio"]
root = Path(sys.argv[1] if len(sys.argv) > 1 else "synthetic")
rng = np.random.default_rng(0)
FPS, W, H = 25, 160, 120


def make_video(path, label, dur):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".v.avi")
    vw = cv2.VideoWriter(str(tmp), cv2.VideoWriter_fourcc(*"MJPG"), FPS, (W, H))
    for t in range(int(dur * FPS)):
        img = rng.integers(40, 90, (H, W, 3), dtype=np.uint8)
        y0, y1, x0, x1 = int(H * 0.6), int(H * 0.7), int(W * 0.4), int(W * 0.6)
        img[y0:y1, x0:x1] = int((170 if label >= 2 else 110) + 30 * np.sin(t / 3))
        vw.write(img)
    vw.release()
    tt = np.arange(int(dur * 16000)) / 16000
    wav = (0.1 * np.sin(2 * np.pi * (330 if label in (1, 3) else 220) * tt) + 0.02 * rng.normal(size=tt.size)).astype(np.float32)
    raw = path.with_suffix(".f32")
    wav.tofile(raw)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(tmp), "-f", "f32le", "-ar", "16000", "-ac", "1", "-i", str(raw),
                    "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(path)], check=True)
    tmp.unlink(); raw.unlink()


def write(rows, name):
    with open(root / name, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(name, len(rows))


fav = []
FAV_M = {0: ["real"], 1: ["rtvc"], 2: ["faceswap", "fsgan", "wav2lip"], 3: ["faceswap-wav2lip", "fsgan-wav2lip"]}
for eth in ["African", "Asian (East)"]:
    for gen in ["men", "women"]:
        for i in range(3):
            ident = f"id{eth[:2]}{gen[0]}{i}"
            for lab, cat in enumerate(CATS):
                for v in range(2):
                    p = root / "fav" / cat / eth / gen / ident / f"{v:05d}.mp4"
                    make_video(p, lab, rng.uniform(3.0, 4.5))
                    fav.append({"path": str(p), "label": lab, "label_str": cat, "identity": ident, "group": ident,
                                "ethnicity": eth, "gender": gen, "language": "English", "lang_code": "en",
                                "dataset": "fakeavceleb", "method": FAV_M[lab][v % len(FAV_M[lab])], "method_from_csv": 1,
                                "source": ident, "target1": "-", "target2": "-", "csv_type": ""})
write(fav, "fav_manifest.csv")
pgf, LANGS = [], [("English", "en"), ("French", "fr"), ("Chinese", "zh"), ("Arabic", "ar")]
A, Vm = ["xtts", "bark+freevc", "vallex", "tacotron+freevc", "microtts+freevc"], ["videoretalking", "wav2lip"]
for src in range(12):
    lang, code = LANGS[src % 4]
    grp = f"pgf_{src:03d}"
    p = root / "pgf" / "real" / f"{src:03d}.mp4"; make_video(p, 0, rng.uniform(3.0, 4.5))
    pgf.append({"path": str(p), "label": 0, "label_str": CATS[0], "identity": grp, "group": grp, "language": lang,
                "lang_code": code, "source_language": lang, "method": "real", "method_from_csv": 0, "dataset": "polyglotfake",
                "gender": "unknown", "ethnicity": "unknown"})
    for j, (tl, tc) in enumerate([x for x in LANGS if x[0] != lang][:3]):
        p = root / "pgf" / "fake" / tl / f"{src:03d}_{j}.mp4"; make_video(p, 3, rng.uniform(3.0, 4.5))
        pgf.append({"path": str(p), "label": 3, "label_str": CATS[3], "identity": grp, "group": grp, "language": tl,
                    "lang_code": tc, "source_language": lang, "method": f"{A[(src + j) % 5]}+{Vm[(src + j) % 2]}",
                    "method_from_csv": 1, "dataset": "polyglotfake", "gender": "unknown", "ethnicity": "unknown"})
write(pgf, "pgf_manifest.csv")
