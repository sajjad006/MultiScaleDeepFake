# HAVDNet-GT / HAVDNet-v2: complete experiment pipeline (FakeAVCeleb + PolyGlotFake)

Two models share the same encoders and synchronization branch:

| | fusion | training |
|---|---|---|
| **HAVDNet-GT** (proposed) | cooperative game: exact Shapley credit of 6 evidence sources → fusion weights | Nash bargaining between the AV, visual and audio objectives (Nash-MTL) |
| **HAVDNet-v2** (strong baseline) | sync-gated mixture of experts | plain sum of losses |

`train.py --fusion shapley --nash` trains GT; `train.py` alone trains v2.

## The two games (`game_theory.py`)

**Game 1: fusion as a cooperative TU game.**
- **Players:** `N = {V_syl, V_word, V_sent, A_syl, A_word, A_sent}`.
- **Characteristic function:** `v(S) = log C − H(p(·|S))`, the evidence (in nats) that coalition S provides about the class.
  - `p(·|S)` is a value network applied to S, with absent players replaced by learned "absent" tokens.
  - The sync score `s_k` is visible only when both `V_k` and `A_k` are in S. Synchrony belongs to the pair, so Shapley splits its credit between the two.
- **Solution:** exact Shapley values over all 64 coalitions in one batched pass, with no sampling. The implementation matches brute force to 3e-15.
- **Fusion weights:** proportional allocation of the positive credit, `w_i ∝ max(φ_i, 0)`.
- **Axioms you can state in the paper:**
  - Efficiency: `Σφ = v(N) − v(∅)`.
  - Symmetry.
  - Null player: a missing modality gets `φ = 0` exactly (verified at 1e-10).
  - Additivity.
- **Training the value function:** each coalition is supervised with the event it can actually identify. AV coalitions get the 4-class label, visual-only coalitions get "video fake?", and audio-only coalitions get "audio fake?". All three are marginals of the same distribution.

**Game 2: learning as a bargaining game.**
- **Players:** the objectives `L_AV`, `L_V` (full visual coalition) and `L_A` (full audio coalition).
- **Utilities:** `u_k(d) = g_kᵀd` for a shared update `d`.
- **Solution:** the Nash bargaining solution `d = Σ α_k g_k` with `GGᵀα = 1/α` (Navon et al., ICML 2022). It is solved as the unique minimiser of a strictly convex function (residual < 1e-8).
- **Properties:** Pareto-optimal, symmetric, and invariant to rescaling any loss (verified at 1e-17). This addresses modality imbalance: visual fakes make up about 95% of FakeAVCeleb fakes, and without bargaining the visual objective would dominate the audio branch.

## Pipeline

```
raw videos ─ tools/make_manifest_{fakeavceleb,polyglotfake}.py ─> manifest.csv
           ─ preprocess.py all ─> per-frame feature store ─> train.py / evaluate.py ─> aggregate.py, tables.py
```
`preprocess.py` replaces both `preprocess_full.py` and the old `precache.py`. Nothing from the old repo is needed.

### What preprocessing does, and why it's fast
| stage | where | what |
|---|---|---|
| `asr` | `--asr_per_gpu` processes per GPU | ffmpeg audio extraction prefetched on threads → WhisperX (`large-v3-turbo` by default, models loaded once, language passed from the manifest) → forced word alignment → language-aware syllables → `align.json` |
| `features` | 1 inference process per GPU + a pool of CPU workers | CPU: decode, MediaPipe FaceLandmarker in VIDEO (tracking) mode **once** per frame on a downscaled copy, then lip (96×48), face (224) and ArcFace-aligned (112, 5-point from the mesh) crops at full resolution. GPU: CLIP ViT-B/32, ArcFace r50 and XLSR-53 in large batches |

- `all` runs both stages at the same time. ASR keeps the GPUs busy while the landmark workers keep every core busy, and the two stages don't depend on each other.
- Prefetch is bounded at 2 jobs per CPU worker, so memory stays flat.
- The progress line reports GPU-busy % and CPU-seconds per video. If GPU busy stays low, add `--cpu_workers` or machines (`--shard i/n`).
- Everything resumes. Failures go to `<store>/<key>/{feat,asr}_error.txt` and are retried on the next run. `python preprocess.py status --store S` gives a summary.

**Compared with `preprocess_full.py`:**
- FaceMesh ran twice per frame in static-image mode at full resolution. It now runs once, in tracking mode, on a downscaled copy.
- WhisperX was reloaded for every video. It now loads once.
- Every frame was written as its own JPEG. Each video is now one lips file plus a few `.npy` arrays.
- An unused phoneme model ran on every video. It's gone.
- Everything ran single-process. It now uses every GPU and core.

**The store keeps features for every frame**, so word/syllable pooling happens inside the DataLoader:
- Timestamp-robustness evaluations (`evaluate.py --perturb σ,shift,drop`) need no re-extraction.
- Disk use is about 2.5 MB per 10 s of video, roughly 40 GB for FakeAVCeleb and 45 GB for PolyGlotFake.

**Compression and noise stores** re-encode the test videos first (H.264 `--crf`, `--scale`, audio `--snr`) and then run the same pipeline. That is the realistic version of the experiment.

### 0. Install and plumbing check (CPU only, about 10 min)
```
pip install torch torchaudio numpy opencv-python soundfile scikit-learn tqdm transformers pyphen mediapipe \
            insightface onnxruntime-gpu whisperx git+https://github.com/openai/CLIP.git      # + ffmpeg on PATH
python tools/make_synthetic.py /tmp/syn
python preprocess.py all --manifest /tmp/syn/fav_manifest.csv --store /tmp/syn_store --smoke_test
python train.py --store /tmp/syn_store --out /tmp/r --fusion shapley --nash --allow_smoke \
                --epochs 3 --bs 8 --workers 0 --device cpu --test_size 0.25 --val_frac 0.2
```

### 1. FakeAVCeleb
```
python tools/make_manifest_fakeavceleb.py --root /ws/FakeAVCeleb_v1.2 --out fav_manifest.csv   # reads meta_data.csv
python preprocess.py all --manifest fav_manifest.csv --store /ws/store_fav
```
Run 20 videos first (`--shard 0/1000`), then check one folder: `meta.json` should show `face_ok_frac` close to 1, and `align.json` should contain words.

### 2. PolyGlotFake
The archive layout and metadata format aren't documented publicly, so check them first:
```
python tools/make_manifest_polyglotfake.py --root /ws/PolyGlotFake --inspect   # labels, languages, methods, GROUPS
python tools/make_manifest_polyglotfake.py --root /ws/PolyGlotFake --out pgf_manifest.csv [--meta <file>] [--group_regex '...']
python preprocess.py all --manifest pgf_manifest.csv --store /ws/store_pgf
```
**Grouping is the leakage-critical step.** Each fake is a translation of a real source clip, so the split must be grouped by source clip (`--group_by group`, which `run_all.sh` sets for PGF). If the inspect report says about 0 fakes are linked to a real group, fix `--group_regex` or use the metadata file's source column.

Syllables are language-aware:
- pyphen for en, fr, es and ru;
- one unit per character for Chinese;
- kana morae for Japanese;
- duration-based pseudo-syllables (about 5 per second) for Arabic. Report this approximation.

### 3. Run everything
```
FAV_MANIFEST=fav_manifest.csv PGF_MANIFEST=pgf_manifest.csv FAV_STORE=/ws/store_fav PGF_STORE=/ws/store_pgf \
TIER=1 PAR=2 bash run_all.sh        # tier 0 (preprocessing) runs automatically if the stores are missing; then TIER=2
```
Resumable. Outputs are `results_fav.md`, `results_pgf.md`, `results_extra.md` (cross-dataset, unseen generators, language/demographic tables and matrices, Shapley credit, sync scores, Nash weights) and `latency.md`. `SEEDS` (default 5) controls the main models and `ABL_SEEDS` (default 3) everything else.

**Rough cost on one A6000.** Each run takes about 30–40 min with cached features, and two run concurrently.

| | FakeAVCeleb | PolyGlotFake |
|---|---|---|
| Tier 1 runs | ~60 | ~45 |
| Preprocessing (1×A6000 + 16 cores, rough) | ~2–3 h | ~2–3 h |
| Corruption stores (test split only) | 4 | 4 |

Training then takes about 30–35 h of wall time for tier 1 on both datasets. Preprocessing scales with GPUs, cores, and machines (`--shard`). Lower it with `SEEDS=3 ABL_SEEDS=2`, or run `DATASETS=fav` first.

## Reviewer concern → experiment → where it lands

| Concern | Runs / evals | Table |
|---|---|---|
| "Game theory" is only an attention gate (all reviewers, AC) | GT has two formally defined games; the ablations below isolate each one | `results_*.md` → game-theory ablations |
| Is the game module necessary vs. concat / cross-attention / transformer? | `gt`, `moe`, `fuse_*`, `gt_uniform` (Shapley weighting removed), `gt_nonash` (bargaining removed), `gt_softmax`, `gt_conf` | fusion + GT ablation tables |
| Multi-seed / significance | 5 seeds for main models, 3 for others; mean ± std and bootstrap CI | every table |
| 99.2% looks implausible | Identity- or source-grouped splits, leakage guards, balanced acc / macro-F1 / AUC / EER with per-class n | every table |
| Forgery-type ID is a lookup table | Supervised generator head (FAV: faceswap / fsgan / wav2lip; PGF: videoretalking / wav2lip) | `method_acc` column |
| Why would a sync pattern indicate a manipulation? | Learned `s_k` and Shapley credit per class and per generator, reported as findings | `results_extra.md` |
| Are PLV / soft-DTW / entropy redundant? | `gt_metric_*`, `gt_noentropy`, `gt_nosync` | tier-2 ablations |
| WhisperX alignment errors | Timestamp jitter, AV offset and dropped words, applied at eval time (`--perturb`) | robustness rows `pert_*` |
| Unseen generators | FAV leave-one-generator-out (4); PGF unseen lip-sync (2) and unseen TTS (5, tier 2); FAV↔PGF zero-shot | unseen-generator + cross-dataset tables |
| Only two datasets / generalization | Both directions of cross-dataset zero-shot, 7-language breakdown, cross-lingual matrix, cross-demographic matrix | `results_extra.md` |
| Compression / noise | Whole-video H.264 CRF 35, 0.5× resolution, audio SNR 10 / 5 dB (re-preprocessed test split) | robustness rows |
| Missing / noisy modality | `drop_a`, `drop_v` at test time (GT handles this by construction via null players) | robustness rows |
| Computational cost | `latency.py`: params, GFLOPs, ms per clip, plus a per-stage breakdown of preprocessing on 20 real clips | `latency.md` |

## Caveats
- **Testing so far.** The whole chain (raw mp4 → preprocess → train → every evaluation → tables) was verified on synthetic videos with stub models. The real MediaPipe, CLIP, XLSR-53, ArcFace and WhisperX calls run for the first time on your machine, so preprocess 20 videos first and inspect the output.
- **Changes from the old crops.** Face crops now go to CLIP at 224 px straight from the full-resolution frame; the old pipeline upsampled a 96 px crop. ArcFace now sees a properly aligned face instead of a full frame.
- **Sentence-scale sync.** It needs at least 6 one-second frames, so short clips get a validity flag of 0. The fraction of valid clips is reported in `sync_stats`.
- **PolyGlotFake labels.** All PGF fakes manipulate both modalities (class 3), so report PGF in the binary setting. The 4-class columns are meaningless there.
- **Nash-MTL compute.** It needs per-task gradients, so GT runs in bf16 (or fp32 on GPUs without bf16) and costs about 1.5× a v2 run.
