"""
tables.py -- paper tables that aggregate.py doesn't cover, built from the per-run JSON files.
  python tables.py --runs runs            -> results_extra.md
Tables: cross-dataset zero-shot, unseen-generator AUC, per-language (PGF) and per-demographic (FAV)
results, cross-lingual and cross-demographic matrices, Shapley credit per class/generator,
learned sync scores per class, Nash bargaining weights.
"""
import argparse
import glob
import json
import re
from collections import defaultdict
from pathlib import Path

import numpy as np


def load(p):
    try:
        return json.load(open(p))
    except Exception:
        return None


def ms(v, k=100):
    v = [x for x in v if x is not None and not (isinstance(x, float) and np.isnan(x))]
    if not v:
        return "--"
    return f"{np.mean(v) * k:.2f} ± {np.std(v, ddof=1) * k:.2f}" if len(v) > 1 else f"{v[0] * k:.2f}"


def seeds(root, ds, name):
    return sorted(p for p in glob.glob(f"{root}/{ds}/{name}_s*") if re.fullmatch(rf"{re.escape(name)}_s\d+", Path(p).name))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--out", default="results_extra.md")
    a = ap.parse_args()
    R, L = a.runs, []

    # ---- cross-dataset
    L += ["## Cross-dataset zero-shot (binary)", "| model | FAV→PGF AUC | FAV→PGF EER | PGF→FAV AUC | PGF→FAV EER |", "|---|---|---|---|---|"]
    for name in ["gt", "moe", "fuse_concat", "fuse_xattn", "fuse_transformer"]:
        f2p = [load(f"{r}/eval_to_pgf/metrics.json") for r in seeds(R, "fav", name)]
        p2f = [load(f"{r}/eval_to_fav/metrics.json") for r in seeds(R, "pgf", name)]
        g = lambda xs, k: [x["metrics"]["binary"].get(k) for x in xs if x]
        if any(f2p) or any(p2f):
            L.append(f"| {name} | {ms(g(f2p, 'auc'))} | {ms(g(f2p, 'eer'))} | {ms(g(p2f, 'auc'))} | {ms(g(p2f, 'eer'))} |")

    # ---- unseen generators
    L += ["", "## Unseen generators (held out of train/val; AUC of held-out fakes vs real test videos)",
          "| dataset | held-out | model | n_unseen | AUC | EER | detected-as-fake |", "|---|---|---|---|---|---|---|"]
    for ds in ("fav", "pgf"):
        names = sorted({Path(p).name.rsplit("_s", 1)[0] for p in glob.glob(f"{R}/{ds}/lomo_*_s*")})
        for name in names:
            hs = [load(f"{r}/test_metrics.json") for r in seeds(R, ds, name)]
            hs = [h["holdout"] for h in hs if h and h.get("holdout")]
            if hs:
                _, m, model = name.split("_", 2)
                L.append(f"| {ds} | {m} | {model} | {hs[0]['n_unseen']} | {ms([h.get('auc_unseen_vs_real') for h in hs])} | "
                         f"{ms([h.get('eer_unseen_vs_real') for h in hs])} | {ms([h['unseen_detected_as_fake'] for h in hs])} |")

    # ---- per-group breakdowns of the main GT model
    for ds, key, title in (("fav", "demographic", "Per-demographic (FAV, GT)"), ("pgf", "language", "Per-language (PGF, GT)")):
        runs = [load(f"{r}/test_metrics.json") for r in seeds(R, ds, "gt")]
        runs = [r for r in runs if r]
        if not runs:
            continue
        L += ["", f"## {title}  (n = test videos; real/fake counts matter for CI width)",
              "| group | n (per class) | bal. acc | binary AUC | binary EER |", "|---|---|---|---|---|"]
        for g in runs[0]["breakdowns"][key]:
            rows = [r["breakdowns"][key].get(g, {}) for r in runs]
            L.append(f"| {g} | {rows[0].get('n')} {rows[0].get('n_per_class')} | {ms([x.get('bal_acc') for x in rows])} | "
                     f"{ms([x.get('bin_auc') for x in rows])} | {ms([x.get('bin_eer') for x in rows])} |")

    # ---- cross-lingual / cross-demographic matrices (train on one group, test on held-out identities of all)
    for ds, pat, key, title in (("pgf", "xlang_*_s0", "language", "Cross-lingual matrix (PGF): binary AUC, row = training language"),
                                ("fav", "xdemo_*_s0", "demographic", "Cross-demographic matrix (FAV): 4-class bal. acc, row = training group")):
        rows = sorted(glob.glob(f"{R}/{ds}/{pat}"))
        res = {Path(r).name[len(pat.split('_')[0]) + 1:-3]: load(f"{r}/test_metrics.json") for r in rows}
        res = {k: v for k, v in res.items() if v}
        if not res:
            continue
        cols = sorted({c for v in res.values() for c in v["breakdowns"][key]})
        metric = "bin_auc" if ds == "pgf" else "bal_acc"
        L += ["", f"## {title}", "| train \\ test | " + " | ".join(cols) + " |", "|---" * (len(cols) + 1) + "|"]
        for k, v in res.items():
            L.append(f"| {k} | " + " | ".join(ms([v["breakdowns"][key].get(c, {}).get(metric)]) for c in cols) + " |")

    # ---- Shapley credit, sync scores, Nash weights
    for ds in ("fav", "pgf"):
        runs = [load(f"{r}/test_metrics.json") for r in seeds(R, ds, "gt")]
        runs = [r for r in runs if r and r.get("shapley_stats")]
        if runs:
            players = ["V_syl", "V_word", "V_sent", "A_syl", "A_word", "A_sent"]
            L += ["", f"## Mean Shapley credit per player, nats ({ds}, GT, mean over seeds)",
                  "| group | n | " + " | ".join(players) + " |", "|---" * (len(players) + 2) + "|"]
            for g in runs[0]["shapley_stats"]:
                vals = [[r["shapley_stats"][g][p] for r in runs if g in r["shapley_stats"]] for p in players]
                L.append(f"| {g} | {runs[0]['shapley_stats'][g]['n']} | " + " | ".join(f"{np.mean(v):.4f}" for v in vals) + " |")
            L += ["", f"## Learned sync score s_k per class ({ds}, GT seed 0; valid-scale mean)",
                  "| group | syllable | word | sentence |", "|---|---|---|---|"]
            for g, row in runs[0]["sync_stats"].items():
                if g.startswith("class:"):
                    L.append(f"| {g} | " + " | ".join(f"{row[k]['mean']:.3f} (valid {row[k]['valid_frac']:.2f})"
                                                      if row[k]["mean"] is not None else "--" for k in ("syllable", "word", "sentence")) + " |")
        hist = [load(f"{r}/history.json") for r in seeds(R, ds, "gt")]
        alphas = defaultdict(list)
        for h in hist:
            if h:
                for k in ("nash_av", "nash_v", "nash_a"):
                    if k in h[-1]["train"]:
                        alphas[k].append(h[-1]["train"][k])
        if alphas:
            L += ["", f"## Nash bargaining weights at the last epoch ({ds}): " +
                  ", ".join(f"{k} = {np.mean(v):.3f} ± {np.std(v):.3f}" for k, v in alphas.items())]
    Path(a.out).write_text("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
