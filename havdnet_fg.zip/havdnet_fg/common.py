"""common.py -- constants and helpers shared by preprocess / data / train / evaluate."""
import hashlib
import math
import numpy as np

CLASS_NAMES = ["RealVideo-RealAudio", "RealVideo-FakeAudio",
               "FakeVideo-RealAudio", "FakeVideo-FakeAudio"]   # label ids used everywhere
SCALES = ["syllable", "word", "sentence"]

MAX_SYL, MAX_WORD, MAX_SENT = 40, 12, 8
FR_SYL, FR_WORD = 5, 4            # frames sampled per syllable / word window
MIN_CTX = 3                       # minimum frames per window
XLSR_STRIDE = 0.020               # seconds per XLSR frame
XLSR_LAYERS = {"syllable": (1, 7), "word": (8, 16), "sentence": (17, 24)}
CACHE_VERSION = 2

VISUAL_TOKENS = {"faceswap", "fsgan", "wav2lip", "wavtolip", "videoretalking"}          # + PolyGlotFake
AUDIO_TOKENS = {"rtvc", "sv2tts", "bark", "freevc", "microtts", "xtts", "tacotron", "vallex"}


def video_key(rel_path: str) -> str:
    """Unique cache key from the path relative to data_root (video stems are NOT unique
    across identity folders, so keying on the stem alone can collide)."""
    return hashlib.md5(rel_path.encode()).hexdigest()[:20]


def pad_window(sf, ef, total, mn=MIN_CTX):
    """Expand [sf, ef) to at least mn frames, clipped to [0, total)."""
    sf, ef = int(sf), int(ef)
    if ef - sf >= mn:
        return max(0, sf), min(total, ef)
    deficit = mn - (ef - sf)
    ns = max(0, sf - deficit // 2)
    ne = min(total, ef + deficit - deficit // 2)
    if ne - ns < mn:
        if ns == 0:
            ne = min(total, mn)
        else:
            ns = max(0, ne - mn)
    return ns, ne


def sample_frames(sf, ef, n):
    """n frame indices spread uniformly over [sf, ef) (old code took the first n frames only)."""
    if ef <= sf:
        return [sf] * n
    return [int(v) for v in np.round(np.linspace(sf, ef - 1, n))]


def visual_method(method: str) -> str:
    """'faceswap-wav2lip' -> 'faceswap+wav2lip'; audio-only/real -> 'none'; unparseable -> ''."""
    if not method:
        return ""
    toks = {t.strip().lower() for t in method.replace("+", "-").replace("_", "-").split("-")}
    toks = {"wav2lip" if t == "wavtolip" else t for t in toks}
    vis = sorted(toks & (VISUAL_TOKENS - {"wavtolip"}))
    if vis:
        return "+".join(vis)
    if toks & (AUDIO_TOKENS | {"real"}):
        return "none"
    return ""


def method_tokens(method: str) -> set:
    toks = {t.strip().lower() for t in (method or "").replace("+", "-").replace("_", "-").split("-")}
    return {"wav2lip" if t == "wavtolip" else t for t in toks if t}


def _group_syllables(words, syllables):
    """Assign each syllable to its word: pyphen syllables are emitted in word order and carry
    word_pos 'i/n'; fall back to midpoint containment."""
    out, wi = [], 0
    for s in syllables:
        pos = s.get("word_pos", "")
        if "/" in pos and wi < len(words):
            i, n = (int(x) for x in pos.split("/"))
            out.append(wi)
            if i == n:
                wi += 1
        else:
            mid = 0.5 * (s["start"] + s["end"])
            j = next((k for k, w in enumerate(words) if w["start"] <= mid <= w["end"]), -1)
            out.append(j)
    return out


def perturb_alignment(words, syllables, sigma_ms=0.0, drop_p=0.0, seed=0, duration=None):
    """Simulate forced-alignment errors. Word boundaries get Gaussian jitter; a word boundary is
    'missed' with prob drop_p (word merged into the previous one). Syllables are re-mapped
    proportionally into their (perturbed) word, exactly as pyphen derived them originally.
    A constant AV offset is applied separately to audio windows (see data.StoreDataset)."""
    if sigma_ms <= 0 and drop_p <= 0:
        return words, syllables
    rng = np.random.default_rng(seed)
    owner = _group_syllables(words, syllables)
    new_w, merged_into = [], []
    for k, w in enumerate(words):
        if new_w and rng.random() < drop_p:
            new_w[-1] = dict(new_w[-1], end=w["end"], word=new_w[-1]["word"] + " " + w["word"])
        else:
            new_w.append(dict(w))
        merged_into.append(len(new_w) - 1)
    hi = duration if duration is not None else max(w["end"] for w in words)
    jit = []
    for w in new_w:
        s = w["start"] + rng.normal(0, sigma_ms / 1e3)
        e = w["end"] + rng.normal(0, sigma_ms / 1e3)
        s, e = min(max(0.0, s), hi), min(max(0.0, e), hi)
        if e <= s:
            e = min(s + 0.04, hi)
        jit.append((s, e))
    span = {}
    for k, w in enumerate(words):                     # original span covered by each new word
        nw = merged_into[k]
        a, b = span.get(nw, (w["start"], w["end"]))
        span[nw] = (min(a, w["start"]), max(b, w["end"]))
    new_s = []
    for s, wo in zip(syllables, owner):
        if wo < 0:
            continue
        nw = merged_into[wo]
        os_, oe = span[nw]
        oe = max(oe, os_ + 1e-3)
        ns, ne = jit[nw]
        a = (s["start"] - os_) / (oe - os_)
        b = (s["end"] - os_) / (oe - os_)
        new_s.append(dict(s, start=ns + a * (ne - ns), end=ns + b * (ne - ns)))
    new_w = [dict(w, start=s, end=e) for w, (s, e) in zip(new_w, jit)]
    return new_w, new_s
