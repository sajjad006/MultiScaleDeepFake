"""
train.py -- train HAVDNet-v2 (or an ablation) and evaluate the best-val checkpoint on the held-out test split.

  python train.py --store /ws/store_fav --out runs/fav/gt_s0 --fusion shapley --nash --seed 0

The split is identity-grouped and written to {out}/split.json. Runs with the same --split_seed
share a split (seed variance = init/order only). Pass --split_file to reuse an existing split.
Outputs: best.pt, split.json, history.json, test_preds.npz, test_metrics.json, val_preds.npz
"""
import argparse
import json
import math
import random
import time
from collections import Counter
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, WeightedRandomSampler

from common import CLASS_NAMES
from data import StoreDataset, collate, filter_split, make_split, method_vocab, scan_store, to_device
from engine import all_metrics, breakdowns, holdout_report, run_inference, shapley_stats, sync_stats
from game_theory import NashMTL
from havdnet_v2 import HAVDNetV2


def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)


def parse():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    io = p.add_argument_group("data")
    io.add_argument("--store", required=True, help="feature store written by preprocess.py")
    io.add_argument("--out", required=True)
    io.add_argument("--split_file", default=None)
    io.add_argument("--split_seed", type=int, default=0)
    io.add_argument("--group_by", default="identity", choices=["identity", "component", "group"],
                    help="group = info['group'] (source-video id; use for PolyGlotFake)")
    io.add_argument("--test_size", type=float, default=0.2)
    io.add_argument("--val_frac", type=float, default=0.1)
    io.add_argument("--train_groups", default=None, help="'African|men': train/val on one demographic")
    io.add_argument("--train_filter", default=None,
                    help="key=value[,key=value]: restrict train/val, e.g. language=English (test untouched)")
    io.add_argument("--holdout_method", default=None, help="e.g. wav2lip: removed from train/val")
    io.add_argument("--allow_smoke", action="store_true")
    m = p.add_argument_group("model / ablations")
    m.add_argument("--fusion", default="moe", choices=["moe", "concat", "xattn", "transformer", "shapley"])
    m.add_argument("--alloc", default="proportional", choices=["proportional", "softmax", "uniform"])
    m.add_argument("--value", default="info", choices=["info", "conf"])
    m.add_argument("--nash", action="store_true", help="Nash-bargaining gradient combination (GT model)")
    m.add_argument("--lambda_coal", type=float, default=1.0, help="coalition (characteristic-fn) loss")
    m.add_argument("--lambda_uni", type=float, default=0.5, help="unimodal coalition losses when --nash is off")
    m.add_argument("--gate_src", default="sync", choices=["sync", "feat", "uniform"])
    m.add_argument("--level_gate", default="mlp", choices=["mlp", "text", "none"])
    m.add_argument("--n_experts", type=int, default=4)
    m.add_argument("--scales", default="0,1,2", help="subset of 0=syllable,1=word,2=sentence")
    m.add_argument("--modality", default="av", choices=["av", "v", "a"])
    m.add_argument("--no_sync", action="store_true")
    m.add_argument("--no_entropy", action="store_true")
    m.add_argument("--metrics", default="corr,plv,sdtw")
    t = p.add_argument_group("optimisation")
    t.add_argument("--epochs", type=int, default=30)
    t.add_argument("--patience", type=int, default=8)
    t.add_argument("--bs", type=int, default=16)
    t.add_argument("--lr", type=float, default=3e-4)
    t.add_argument("--wd", type=float, default=1e-4)
    t.add_argument("--label_smoothing", type=float, default=0.05)
    t.add_argument("--balance", default="weights", choices=["weights", "sampler", "none"])
    t.add_argument("--lambda_method", type=float, default=0.3, help="generator head (0 = off)")
    t.add_argument("--lambda_sync", type=float, default=0.0,
                   help="optional prior: s_k -> 1 for RVRA, 0 otherwise (default off: s is learned via CE only)")
    t.add_argument("--lambda_lb", type=float, default=0.01, help="MoE load balance")
    t.add_argument("--select", default="macro_f1", choices=["macro_f1", "bal_acc", "bin_auc"])
    t.add_argument("--precision", default="auto", choices=["auto", "bf16", "fp16", "fp32"])
    t.add_argument("--seed", type=int, default=0)
    t.add_argument("--workers", type=int, default=8)
    t.add_argument("--no_amp", action="store_true")
    t.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    t.add_argument("--max_steps", type=int, default=0, help="debug: stop each epoch after N steps")
    return p.parse_args()


def main():
    a = parse()
    set_seed(a.seed)
    torch.backends.cudnn.benchmark = True                 # input shapes are fixed (MAX_* padding)
    torch.backends.cuda.matmul.allow_tf32 = True          # Ampere+: fp32 matmuls/convs on tensor cores
    torch.backends.cudnn.allow_tf32 = True
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    dev, amp = a.device, (not a.no_amp) and a.device.startswith("cuda")
    infos = scan_store(a.store, a.allow_smoke)
    by_key = {i["key"]: i for i in infos}

    # ---------------- split
    if a.split_file:
        base = json.load(open(a.split_file))["base_splits"]
    else:
        base = make_split(infos, a.test_size, a.val_frac, a.split_seed, a.group_by)
    sp = filter_split(base, infos, a.train_groups, a.holdout_method, a.train_filter)
    for part, keys in sp.items():
        c = Counter(by_key[k]["label"] for k in keys)
        print(f"  {part:5s} n={len(keys):6d}  " + "  ".join(f"{CLASS_NAMES[i][:12]}={c.get(i, 0)}" for i in range(4)))
    if min(len(sp["train"]), len(sp["val"])) == 0:
        raise SystemExit("empty train/val after filtering")
    mvocab = method_vocab(infos, sp["train"]) if a.lambda_method > 0 else None
    print(f"  generator head: {mvocab if mvocab else 'disabled'}")
    json.dump({"base_splits": base, "splits": sp, "args": vars(a), "method_vocab": mvocab},
              open(out / "split.json", "w"))

    # ---------------- data
    ds = {k: StoreDataset(a.store, infos, sp[k], augment=(k == "train"), mvocab=mvocab)
          for k in ("train", "val", "test")}
    ytr = ds["train"].labels()
    cnt = Counter(ytr)
    if a.balance == "sampler":
        w = [1.0 / cnt[y] for y in ytr]
        sampler, shuffle = WeightedRandomSampler(w, len(ytr), replacement=True), False
    else:
        sampler, shuffle = None, True
    kw = dict(collate_fn=collate, num_workers=a.workers, pin_memory=dev.startswith("cuda"),
              persistent_workers=a.workers > 0)
    dl_tr = DataLoader(ds["train"], a.bs, shuffle=shuffle, sampler=sampler, drop_last=True, **kw)
    dl_va = DataLoader(ds["val"], a.bs * 2, shuffle=False, **kw)
    dl_te = DataLoader(ds["test"], a.bs * 2, shuffle=False, **kw)

    # ---------------- model
    cfg = dict(fusion=a.fusion, alloc=a.alloc, value=a.value, gate_src=a.gate_src, level_gate=a.level_gate, n_experts=a.n_experts,
               scales=tuple(int(x) for x in a.scales.split(",")), modality=a.modality,
               sync=not a.no_sync, entropy=not a.no_entropy, metrics=tuple(a.metrics.split(",")),
               n_methods=len(mvocab) if mvocab else 0)
    prompts = None
    if a.level_gate == "text":
        pr = torch.load(Path(a.store) / "prompts.pt", weights_only=False)
        assert pr["names"] == CLASS_NAMES, "prompt order mismatch"
        prompts = pr["emb"]
    model = HAVDNetV2(cfg, prompts).to(dev)
    n_tr = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"  model cfg: {model.cfg}\n  trainable params: {n_tr:,}")

    cw = None
    if a.balance == "weights":
        cw = torch.tensor([math.sqrt(len(ytr) / max(cnt.get(c, 0), 1)) for c in range(4)], dtype=torch.float32)
        cw = (cw / cw.mean()).to(dev)
    ce = nn.CrossEntropyLoss(weight=cw, label_smoothing=a.label_smoothing)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=a.wd)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=a.lr, epochs=a.epochs,
                                                steps_per_epoch=max(1, a.max_steps or len(dl_tr)), pct_start=0.05)
    prec = a.precision
    if prec == "auto":
        prec = ("bf16" if torch.cuda.is_bf16_supported() else "fp16") if dev.startswith("cuda") else "fp32"
    if a.nash and prec == "fp16":
        prec = "fp32"                                   # per-task autograd.grad + GradScaler don't mix
    adt = {"bf16": torch.bfloat16, "fp16": torch.float16, "fp32": torch.float32}[prec]
    scaler = torch.amp.GradScaler("cuda", enabled=(prec == "fp16"))
    nash = NashMTL(model.parameters(), 3) if a.nash else None
    if a.nash and a.fusion != "shapley":
        raise SystemExit("--nash needs the unimodal coalition objectives of --fusion shapley")
    print(f"  precision={prec}  nash={a.nash}")

    # ---------------- train
    best, best_ep, hist, bad = -1.0, 0, [], 0
    for ep in range(1, a.epochs + 1):
        model.train()
        t0, run, n = time.time(), Counter(), 0
        for step, b in enumerate(dl_tr):
            if a.max_steps and step >= a.max_steps:
                break
            b = to_device(b, dev)
            with torch.autocast(device_type=dev.split(":")[0], dtype=adt, enabled=prec != "fp32"):
                o = model(b)
                loss = ce(o["logits"].float(), b["label"])
                parts = {"ce": loss.item()}
                if o["method_logits"] is not None and (b["method"] >= 0).any():
                    lm = F.cross_entropy(o["method_logits"].float(), b["method"], ignore_index=-1)
                    loss = loss + a.lambda_method * lm; parts["method"] = lm.item()
                if a.lambda_sync > 0 and o["sync_valid"].sum() > 0:
                    tgt = (b["label"] == 0).float()[:, None].expand_as(o["s"])
                    vm = o["sync_valid"]
                    ls = (F.binary_cross_entropy(o["s"].float().clamp(1e-5, 1 - 1e-5), tgt, reduction="none")
                          * vm).sum() / vm.sum()
                    loss = loss + a.lambda_sync * ls; parts["sync"] = ls.item()
                if o["router"] is not None and a.lambda_lb > 0:
                    mw = o["router"].float().mean(0)
                    lb = F.mse_loss(mw, torch.full_like(mw, 1.0 / mw.numel()))
                    loss = loss + a.lambda_lb * lb; parts["lb"] = lb.item()
                L_v = L_a = None
                if "gt" in o:
                    lc, L_v, L_a = model.fusion.coalition_losses(o["gt"], b["label"])
                    loss = loss + a.lambda_coal * lc
                    parts.update(coal=lc.item(), uni_v=L_v.item(), uni_a=L_a.item())
            opt.zero_grad(set_to_none=True)
            if nash is not None:
                alpha = nash.backward([loss, L_v, L_a])
                parts.update({f"nash_{k}": float(v) for k, v in zip(("av", "v", "a"), alpha)})
                nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                opt.step(); sched.step()
            else:
                if L_v is not None:
                    loss = loss + a.lambda_uni * (L_v + L_a)
                scaler.scale(loss).backward()
                scaler.unscale_(opt)
                nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                scaler.step(opt); scaler.update(); sched.step()
            run.update(parts); n += 1
        pv = run_inference(model, dl_va, dev, amp)
        vm_ = all_metrics(pv, mvocab)
        score = vm_["binary"].get("auc", 0.0) if a.select == "bin_auc" else vm_["four_class"][a.select]
        rec = {"epoch": ep, "train": {k: v / max(n, 1) for k, v in run.items()},
               "val": {"acc": vm_["four_class"]["acc"], "bal_acc": vm_["four_class"]["bal_acc"],
                       "macro_f1": vm_["four_class"]["macro_f1"], "bin_auc": vm_["binary"].get("auc")},
               "sec": round(time.time() - t0, 1)}
        hist.append(rec)
        print(f"E{ep:02d} {rec['train']}  val bal_acc={rec['val']['bal_acc']:.4f} "
              f"F1={rec['val']['macro_f1']:.4f}  ({rec['sec']}s)")
        if score > best:
            best, best_ep, bad = score, ep, 0
            torch.save({"state": model.state_dict(), "cfg": model.cfg, "epoch": ep, "val": rec["val"],
                        "args": vars(a), "method_vocab": mvocab}, out / "best.pt")
        else:
            bad += 1
            if bad >= a.patience:
                print(f"early stop at epoch {ep}")
                break
        json.dump(hist, open(out / "history.json", "w"), indent=1)

    # ---------------- test (held-out identities, never seen in train/val)
    ck = torch.load(out / "best.pt", map_location=dev, weights_only=False)
    model.load_state_dict(ck["state"])
    np.savez_compressed(out / "val_preds.npz", **run_inference(model, dl_va, dev, amp))
    pt = run_inference(model, dl_te, dev, amp)
    np.savez_compressed(out / "test_preds.npz", **pt)
    res = {"best_epoch": best_ep, "metrics": all_metrics(pt, mvocab),
           "breakdowns": breakdowns(pt, by_key), "sync_stats": sync_stats(pt, by_key),
           "shapley_stats": shapley_stats(pt, by_key)}
    if a.holdout_method:
        res["holdout"] = holdout_report(pt, by_key, a.holdout_method)
    json.dump(res, open(out / "test_metrics.json", "w"), indent=1, default=float)
    m4, mb = res["metrics"]["four_class"], res["metrics"]["binary"]
    print(f"\nTEST (epoch {best_ep}) 4-class acc={m4['acc']:.4f} bal_acc={m4['bal_acc']:.4f} "
          f"F1={m4['macro_f1']:.4f} | binary AUC={mb.get('auc', float('nan')):.4f} "
          f"EER={mb.get('eer', float('nan')):.4f} bal_acc={mb['bal_acc']:.4f}")
    if res.get("holdout"):
        print("HOLDOUT", res["holdout"])


if __name__ == "__main__":
    main()
