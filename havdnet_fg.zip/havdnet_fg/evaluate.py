"""
evaluate.py -- re-evaluate a trained run.

  # held-out test split (same as end of train.py) + exact Shapley attribution over scales
  python evaluate.py --run runs/main_s0 --shapley
  # timestamp robustness: same test videos, perturbed-alignment cache
  python evaluate.py --run runs/fav/gt_s0 --perturb 40,0,0 --tag pert_40_0_0
  # compression / noise: a store preprocessed from re-encoded test videos
  python evaluate.py --run runs/fav/gt_s0 --store /ws/store_fav_crf35 --tag crf35
  # cross-dataset zero-shot (e.g. PolyGlotFake preprocessed into the same layout)
  python evaluate.py --run runs/fav/gt_s0 --store /ws/store_pgf \
                     --split all --tag polyglot

--split all refuses to run if any evaluated video belongs to the run's train/val split.
"""
import argparse
import json
from itertools import permutations
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from data import StoreDataset, collate, scan_store, to_device
from engine import all_metrics, breakdowns, holdout_report, run_inference, shapley_stats, sync_stats
from havdnet_v2 import HAVDNetV2


@torch.no_grad()
def shapley_scales(model, loader, dev):
    """Exact Shapley values of the 3 scales (players) for the true-class logit.
    Removing a scale = its fused feature -> eval-set mean, its sync score -> 0.5 sentinel."""
    model.eval()
    sums, n = torch.zeros(3, model.cfg["d"], device=dev), 0
    for b in loader:                                     # pass 1: baseline = mean fused feature
        b = to_device(b, dev)
        e = model.encode(b); s, sv, _ = model.sync(e)
        o = model.head(e, s, sv)
        sums += torch.stack([f.float().sum(0) for f in o["fhat"]]); n += len(b["key"])
    model.f_baseline.copy_(sums / max(n, 1))
    phis, labels, keys = [], [], []
    for b in loader:                                     # pass 2: 8 coalitions, 6 orderings
        b = to_device(b, dev)
        e = model.encode(b); s, sv, _ = model.sync(e)
        y = b["label"]
        cache = {}

        def v(S):
            S = frozenset(S)
            if S not in cache:
                drop = tuple(k for k in range(3) if k not in S)
                cache[S] = model.head(e, s, sv, drop=drop)["logits"].float().gather(1, y[:, None]).squeeze(1)
            return cache[S]

        acc = torch.zeros(len(y), 3, device=dev)
        for p in permutations(range(3)):
            for i, k in enumerate(p):
                acc[:, k] += v(p[:i + 1]) - v(p[:i])
        phi = acc / 6
        assert torch.allclose(phi.sum(1), v((0, 1, 2)) - v(()), atol=1e-3)
        phis.append(phi.cpu()); labels.append(y.cpu()); keys += b["key"]
    return {"phi": torch.cat(phis).numpy(), "labels": torch.cat(labels).numpy(), "keys": np.array(keys)}


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--run", required=True)
    p.add_argument("--store", default=None, help="default: the run's training store")
    p.add_argument("--perturb", default=None, help="sigma_ms,shift_ms,drop_p: simulated alignment errors")
    p.add_argument("--split", default="test", choices=["test", "val", "all"])
    p.add_argument("--tag", default=None)
    p.add_argument("--shapley", action="store_true", help="exact scale-Shapley for moe/concat models")
    p.add_argument("--drop_modality", default=None, choices=["a", "v"], help="missing-modality test")
    p.add_argument("--bs", type=int, default=32)
    p.add_argument("--workers", type=int, default=8)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--allow_smoke", action="store_true")
    a = p.parse_args()

    torch.backends.cudnn.benchmark = True
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    run = Path(a.run)
    ck = torch.load(run / "best.pt", map_location=a.device, weights_only=False)
    targs, sp = ck["args"], json.load(open(run / "split.json"))
    store = a.store or targs["store"]
    infos = scan_store(store, a.allow_smoke or targs.get("allow_smoke", False))
    by_key = {i["key"]: i for i in infos}
    if a.split == "all":
        keys = [i["key"] for i in infos]
        seen = set(sp["splits"]["train"]) | set(sp["splits"]["val"])
        overlap = seen & set(keys)
        if overlap:
            raise SystemExit(f"refusing --split all: {len(overlap)} videos were used for training/validation")
    else:
        keys = [k for k in sp["splits"][a.split] if k in by_key]
        if len(keys) < len(sp["splits"][a.split]):
            print(f"[WARN] {len(sp['splits'][a.split]) - len(keys)} split videos missing from {store}")

    prompts = None
    if ck["cfg"]["level_gate"] == "text":
        prompts = torch.load(Path(targs["store"]) / "prompts.pt", weights_only=False)["emb"]
    model = HAVDNetV2(ck["cfg"], prompts).to(a.device)
    model.load_state_dict(ck["state"])
    mvocab = ck.get("method_vocab")
    pert = tuple(float(x) for x in a.perturb.split(",")) if a.perturb else None
    ds = StoreDataset(store, infos, keys, augment=False, mvocab=mvocab, perturb=pert)
    dl = DataLoader(ds, a.bs, shuffle=False, collate_fn=collate, num_workers=a.workers)

    tag = a.tag or a.split
    od = run / f"eval_{tag}"
    od.mkdir(exist_ok=True)
    pr = run_inference(model, dl, a.device, drop_mod=a.drop_modality)
    np.savez_compressed(od / "preds.npz", **pr)
    res = {"store": str(store), "perturb": a.perturb, "split": a.split, "metrics": all_metrics(pr, mvocab),
           "breakdowns": breakdowns(pr, by_key), "sync_stats": sync_stats(pr, by_key),
           "shapley_stats": shapley_stats(pr, by_key), "drop_modality": a.drop_modality}
    if targs.get("holdout_method"):
        res["holdout"] = holdout_report(pr, by_key, targs["holdout_method"])
    if a.shapley:
        if model.cfg["fusion"] not in ("moe", "concat") or a.drop_modality:
            print("[WARN] Shapley skipped: only defined for fusion=moe/concat")
        else:
            sh = shapley_scales(model, dl, a.device)
            np.savez_compressed(od / "shapley.npz", **sh)
            res["shapley_mean_abs"] = {
                str(c): np.abs(sh["phi"][sh["labels"] == c]).mean(0).tolist() for c in range(4)}
            res["shapley_mean"] = {str(c): sh["phi"][sh["labels"] == c].mean(0).tolist() for c in range(4)}
    json.dump(res, open(od / "metrics.json", "w"), indent=1, default=float)
    m4, mb = res["metrics"]["four_class"], res["metrics"]["binary"]
    print(f"[{tag}] n={len(keys)} 4-class bal_acc={m4['bal_acc']:.4f} F1={m4['macro_f1']:.4f} | "
          f"binary AUC={mb.get('auc', float('nan')):.4f} EER={mb.get('eer', float('nan')):.4f}")


if __name__ == "__main__":
    main()
