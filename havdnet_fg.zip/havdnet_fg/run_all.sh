#!/usr/bin/env bash
# run_all.sh -- every experiment for the paper, on FakeAVCeleb (fav) and PolyGlotFake (pgf).
#
#   TIER=0 bash run_all.sh     # preprocessing only (raw videos -> feature stores, all GPUs + all cores)
#   TIER=1 bash run_all.sh     # main results + every reviewer-requested experiment
#   TIER=2 bash run_all.sh     # + secondary ablations, cross-demographic, cross-lingual, PGF unseen-TTS
#   DATASETS="fav" TIER=1 ...  # one dataset only;  SEEDS=3 to cut cost
# Resumable: finished preprocessing / runs / evals are skipped. Tables -> results_fav.md, results_pgf.md, results_extra.md
set -uo pipefail
FAV_MANIFEST=${FAV_MANIFEST:-fav_manifest.csv}       # tools/make_manifest_fakeavceleb.py
PGF_MANIFEST=${PGF_MANIFEST:-pgf_manifest.csv}       # tools/make_manifest_polyglotfake.py
FAV_STORE=${FAV_STORE:-/workspace/store_fav}
PGF_STORE=${PGF_STORE:-/workspace/store_pgf}
PRE_ARGS=${PRE_ARGS:-}                               # extra preprocess.py args, e.g. "--gpus 0,1 --asr_per_gpu 2"
RUNS=${RUNS:-runs}
TIER=${TIER:-1}
PAR=${PAR:-2}
SEEDS=${SEEDS:-5}
DATASETS=${DATASETS:-"fav pgf"}
WORKERS=${WORKERS:-6}
ABL_SEEDS=${ABL_SEEDS:-3}              # seeds for ablations / baselines / unseen-generator runs
TRAIN_EXTRA=${TRAIN_EXTRA:-}           # passthrough (plumbing tests: "--epochs 1 --max_steps 2 --device cpu --allow_smoke")
EVAL_EXTRA=${EVAL_EXTRA:-}
PRE_EXTRA=${PRE_EXTRA:-}               # e.g. "--smoke_test" for plumbing tests
mkdir -p "$RUNS" logs

store()    { [[ $1 == fav ]] && echo "$FAV_STORE" || echo "$PGF_STORE"; }
manifest() { [[ $1 == fav ]] && echo "$FAV_MANIFEST" || echo "$PGF_MANIFEST"; }
dsargs() { [[ $1 == fav ]] && echo "--select macro_f1" || echo "--group_by group --select bin_auc"; }
GT="--fusion shapley --nash"
seq_s() { seq 0 $(( $1 - 1 )); }
throttle() { while (( $(jobs -rp | wc -l) >= PAR )); do sleep 15; done; }

run() {  # run <ds> <name> <seed> [train args...]
  local ds=$1 name=$2 seed=$3; shift 3
  local out="$RUNS/$ds/${name}_s${seed}" split=()
  [[ -f "$out/test_metrics.json" ]] && return
  [[ -f "$RUNS/$ds/gt_s0/split.json" && "$out" != "$RUNS/$ds/gt_s0" ]] && split=(--split_file "$RUNS/$ds/gt_s0/split.json")
  mkdir -p "$RUNS/$ds"
  echo "[run] $out $*"
  python train.py --store "$(store $ds)" --workers $WORKERS --out "$out" \
         --seed "$seed" $(dsargs $ds) "${split[@]}" "$@" $TRAIN_EXTRA > "logs/${ds}_${name}_s${seed}.log" 2>&1 \
    || echo "[FAIL] $out (see logs/${ds}_${name}_s${seed}.log)"
}
ev() {   # ev <run_dir> <tag> [evaluate args...]
  local r=$1 tag=$2; shift 2
  [[ -f "$r/best.pt" && ! -f "$r/eval_$tag/metrics.json" ]] || return 0
  python evaluate.py --run "$r" --tag "$tag" "$@" $EVAL_EXTRA > "logs/eval_$(basename $(dirname $r))_$(basename $r)_$tag.log" 2>&1 \
    || echo "[FAIL] eval $r $tag"
}
cstore() {  # cstore <ds> <tag> [preprocess args...] : TEST-split store preprocessed from corrupted videos
  local ds=$1 tag=$2; shift 2
  local dir="$(store $ds)_$tag"
  [[ -f "$dir/.done" ]] && return
  python preprocess.py all --manifest "$(manifest $ds)" --store "$dir" --keys "$RUNS/$ds/gt_s0/split.json:test" \
         "$@" $PRE_ARGS $PRE_EXTRA > "logs/cstore_${ds}_$tag.log" 2>&1 && touch "$dir/.done"
}

# ============================================================ tier 0: preprocessing (raw videos -> stores)
for ds in $DATASETS; do
  [[ -f "$(store $ds)/.done" ]] && continue
  [[ -f "$(manifest $ds)" ]] || { echo "missing manifest $(manifest $ds) (see README)"; exit 1; }
  python preprocess.py all --manifest "$(manifest $ds)" --store "$(store $ds)" $PRE_ARGS $PRE_EXTRA 2>&1 | tee logs/preprocess_$ds.log
  grep -q "errors 0) | alignment" logs/preprocess_$ds.log && touch "$(store $ds)/.done"
done
(( TIER == 0 )) && exit 0

# ============================================================ tier 1
for ds in $DATASETS; do
  run $ds gt 0 $GT                                         # defines the shared split for this dataset
  for s in $(seq 1 $(( SEEDS - 1 ))); do throttle; run $ds gt $s $GT & done
  for s in $(seq_s $SEEDS); do throttle; run $ds moe $s & done
  for s in $(seq_s $ABL_SEEDS); do
    for f in concat xattn transformer; do throttle; run $ds fuse_$f $s --fusion $f & done
    throttle; run $ds gt_nonash  $s --fusion shapley &                       # game 1 only
    throttle; run $ds gt_softmax $s $GT --alloc softmax &                   # allocation rule
    throttle; run $ds gt_uniform $s $GT --alloc uniform &                   # no Shapley weighting
    throttle; run $ds gt_conf    $s $GT --value conf &                      # characteristic function
    throttle; run $ds moe_gfeat  $s --gate_src feat &
  done
  if [[ $ds == fav ]]; then H="faceswap fsgan wav2lip rtvc"; else H="videoretalking wav2lip"; fi
  for m in $H; do for s in $(seq_s $ABL_SEEDS); do
    throttle; run $ds lomo_${m}_gt $s $GT --holdout_method $m &
    throttle; run $ds lomo_${m}_moe $s --holdout_method $m &
  done; done
done
wait

# ---------------- robustness: alignment errors are simulated at eval time (per-frame store),
#                  compression / noise use test-split stores preprocessed from corrupted videos
for ds in $DATASETS; do
  if [[ $ds == fav ]]; then P="40,0,0 80,0,0 0,80,0 0,160,0 0,0,0.1 0,0,0.3"; else P="40,0,0 0,80,0 0,0,0.3"; fi
  cstore $ds crf35 --crf 35 --reuse_align "$(store $ds)"
  cstore $ds scale50 --scale 0.5 --reuse_align "$(store $ds)"
  cstore $ds snr10 --snr 10
  cstore $ds snr5 --snr 5
  for name in gt moe; do for s in $(seq_s $SEEDS); do
    r="$RUNS/$ds/${name}_s$s"
    for p in $P; do ev "$r" "pert_${p//,/_}" --perturb "$p"; done
    for c in crf35 scale50 snr10 snr5; do ev "$r" "$c" --store "$(store $ds)_$c"; done
    ev "$r" drop_a --drop_modality a
    ev "$r" drop_v --drop_modality v
  done; done
  for s in $(seq_s $SEEDS); do ev "$RUNS/$ds/moe_s$s" scaleshap --shapley; done
done

# ---------------- cross-dataset zero-shot (both directions)
if [[ "$DATASETS" == *fav* && "$DATASETS" == *pgf* ]]; then
  for name in gt moe fuse_concat fuse_xattn fuse_transformer; do for s in $(seq_s $SEEDS); do
    ev "$RUNS/fav/${name}_s$s" to_pgf --store "$PGF_STORE" --split all
    ev "$RUNS/pgf/${name}_s$s" to_fav --store "$FAV_STORE" --split all
  done; done
fi

# ============================================================ tier 2
if (( TIER >= 2 )); then
  for ds in $DATASETS; do
    for s in $(seq_s $ABL_SEEDS); do
      throttle; run $ds gt_nosync $s $GT --no_sync &
      throttle; run $ds gt_noentropy $s $GT --no_entropy &
      for m in corr plv sdtw; do throttle; run $ds gt_metric_$m $s $GT --metrics $m & done
      for k in 0 1 2; do throttle; run $ds gt_scale_$k $s --fusion shapley --scales $k & done
      for mod in v a; do throttle; run $ds gt_modality_$mod $s --fusion shapley --modality $mod & done
    done
  done
  if [[ "$DATASETS" == *fav* ]]; then
    for eth in "African" "Asian (East)" "Asian (South)" "Caucasian (American)" "Caucasian (European)"; do
      for gen in men women; do
        throttle; run fav "xdemo_$(echo "$eth" | tr -cd 'A-Za-z')_$gen" 0 $GT --train_groups "$eth|$gen" &
      done
    done
  fi
  if [[ "$DATASETS" == *pgf* ]]; then
    for L in English French Spanish Russian Chinese Arabic Japanese; do
      throttle; run pgf "xlang_$L" 0 $GT --train_filter "language=$L" &
    done
    for m in xtts bark vallex tacotron microtts; do for s in $(seq_s $ABL_SEEDS); do
      throttle; run pgf lomo_${m}_gt $s $GT --holdout_method $m &
    done; done
  fi
  wait
fi

# ============================================================ cost + tables
rm -f latency.md
for ds in $DATASETS; do
  [[ -f "$RUNS/$ds/gt_s0/best.pt" ]] && python latency.py --run "$RUNS/$ds/gt_s0" "$RUNS/$ds/moe_s0" \
     "$RUNS/$ds/fuse_transformer_s0" --manifest "$(manifest $ds)" --n 20 \
     $( [[ "$EVAL_EXTRA" == *cpu* ]] && echo "--device cpu" ) $( [[ "$PRE_EXTRA" == *smoke* ]] && echo "--smoke_test" ) \
     > logs/latency_$ds.log 2>&1 && break
done
for ds in $DATASETS; do
  md=results_$ds.md; rm -f $md; R="$RUNS/$ds"
  echo "## main + fusion comparison ($ds)" >> $md
  python aggregate.py --md $md --table --runs "$R/gt_s[0-9]*" "$R/moe_s[0-9]*" "$R/fuse_concat_s[0-9]*" "$R/fuse_xattn_s[0-9]*" \
     "$R/fuse_transformer_s[0-9]*" "$R/moe_gfeat_s[0-9]*" > /dev/null
  echo -e "\n## game-theory ablations ($ds)" >> $md
  python aggregate.py --md $md --table --runs "$R/gt_s[0-9]*" "$R/gt_nonash_s[0-9]*" "$R/gt_softmax_s[0-9]*" "$R/gt_uniform_s[0-9]*" \
     "$R/gt_conf_s[0-9]*" > /dev/null
  echo -e "\n## unseen generators ($ds; see holdout{} in test_metrics.json for unseen-vs-real AUC)" >> $md
  python aggregate.py --md $md --table --runs $(ls -d $R/lomo_*_s0 2>/dev/null | sed 's/_s0$/_s[0-9]*/') > /dev/null
  for name in gt moe; do
    echo -e "\n## robustness: $name ($ds)" >> $md
    for t in $(ls -d $R/${name}_s0/eval_* 2>/dev/null | xargs -n1 basename | sed 's/eval_//'); do
      python aggregate.py --md $md --runs "$R/${name}_s[0-9]*" --eval $t --name "$name / $t" > /dev/null
    done
  done
  if (( TIER >= 2 )); then
    echo -e "\n## sync / scale / modality ablations ($ds)" >> $md
    python aggregate.py --md $md --table --runs "$R/gt_nosync_s[0-9]*" "$R/gt_noentropy_s[0-9]*" "$R/gt_metric_corr_s[0-9]*" \
       "$R/gt_metric_plv_s[0-9]*" "$R/gt_metric_sdtw_s[0-9]*" "$R/gt_scale_0_s[0-9]*" "$R/gt_scale_1_s[0-9]*" "$R/gt_scale_2_s[0-9]*" \
       "$R/gt_modality_v_s[0-9]*" "$R/gt_modality_a_s[0-9]*" > /dev/null
  fi
done
python tables.py --runs "$RUNS" > /dev/null 2>&1 || true
echo "done -> results_*.md, results_extra.md, latency.md ; per-run JSON under $RUNS/<ds>/*/"
