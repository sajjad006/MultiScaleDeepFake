"""engine.py -- inference, metrics, breakdowns, bootstrap. Shared by train / evaluate / aggregate."""
from collections import defaultdict

import numpy as np
import torch
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score, roc_auc_score, roc_curve)

from common import CLASS_NAMES, method_tokens
from data import to_device


@torch.no_grad()
def run_inference(model, loader, dev, amp=True, drop_mod=None):
    model.eval()
    rec = defaultdict(list)
    for b in loader:
        b = to_device(b, dev)
        b["drop_mod"] = drop_mod
        with torch.autocast(device_type=dev.split(":")[0], dtype=torch.float16,
                            enabled=amp and dev.startswith("cuda")):
            o = model(b)
        rec["keys"] += b["key"]
        rec["labels"].append(b["label"].cpu())
        rec["probs"].append(torch.softmax(o["logits"].float(), -1).cpu())
        rec["s"].append(o["s"].float().cpu())
        rec["sync_valid"].append(o["sync_valid"].float().cpu())
        rec["alpha"].append(o["alpha"].float().cpu())
        if o["router"] is not None:
            rec["router"].append(o["router"].float().cpu())
        rec["method_true"].append(b["method"].cpu())
        if "gt" in o:
            rec["phi"].append(o["gt"]["phi"].float().cpu())
        if o["method_logits"] is not None:
            rec["method_probs"].append(torch.softmax(o["method_logits"].float(), -1).cpu())
        if any(r is not None for r in o["sync_raw"]):
            M = next(r["metrics"].shape[1] for r in o["sync_raw"] if r is not None)
            rec["sync_metrics"].append(torch.stack(
                [r["metrics"].float().cpu() if r is not None else torch.full((len(b["key"]), M), np.nan)
                 for r in o["sync_raw"]], 1))
    out = {"keys": np.array(rec.pop("keys"))}
    for k, v in rec.items():
        out[k] = torch.cat(v).numpy() if v else np.zeros((len(out["keys"]), 0))
    return out


# ------------------------------------------------------------------ metrics
def eer(y, score):
    fpr, tpr, _ = roc_curve(y, score)
    fnr = 1 - tpr
    i = np.nanargmin(np.abs(fnr - fpr))
    return float((fpr[i] + fnr[i]) / 2)


def four_class(y, p):
    pred = p.argmax(1)
    m = {"acc": accuracy_score(y, pred), "bal_acc": balanced_accuracy_score(y, pred),
         "macro_f1": f1_score(y, pred, average="macro", zero_division=0),
         "macro_precision": precision_score(y, pred, average="macro", zero_division=0),
         "macro_recall": recall_score(y, pred, average="macro", zero_division=0),
         "confusion": confusion_matrix(y, pred, labels=range(4)).tolist()}
    present = np.unique(y)
    if len(present) == 4:
        m["auc_ovr"] = roc_auc_score(y, p, multi_class="ovr", average="macro", labels=range(4))
    return m


def binary(y, p):
    """real = RVRA (class 0); fake = any manipulated modality. score = 1 - p(RVRA)."""
    yb = (y != 0).astype(int)
    score = 1 - p[:, 0]
    pred = (p.argmax(1) != 0).astype(int)
    m = {"acc": accuracy_score(yb, pred), "bal_acc": balanced_accuracy_score(yb, pred),
         "f1_fake": f1_score(yb, pred, zero_division=0),
         "macro_f1": f1_score(yb, pred, average="macro", zero_division=0),
         "n_real": int((yb == 0).sum()), "n_fake": int(yb.sum())}
    if 0 < yb.sum() < len(yb):
        m["auc"] = roc_auc_score(yb, score)
        m["eer"] = eer(yb, score)
    return m


def method_metrics(mt, mp, vocab):
    if mp.size == 0 or vocab is None:
        return None
    ok = mt >= 0
    if ok.sum() == 0:
        return None
    pred = mp[ok].argmax(1)
    return {"n": int(ok.sum()), "acc": accuracy_score(mt[ok], pred),
            "macro_f1": f1_score(mt[ok], pred, average="macro", zero_division=0),
            "confusion": confusion_matrix(mt[ok], pred, labels=range(len(vocab))).tolist(),
            "classes": vocab}


def all_metrics(pr, vocab=None):
    y, p = pr["labels"], pr["probs"]
    return {"n": len(y), "n_per_class": {CLASS_NAMES[c]: int((y == c).sum()) for c in range(4)},
            "four_class": four_class(y, p), "binary": binary(y, p),
            "method": method_metrics(pr.get("method_true", np.zeros(0)), pr.get("method_probs", np.zeros(0)), vocab)}


def breakdowns(pr, by_key):
    """Per-demographic and per-generator results, always with counts."""
    y, p = pr["labels"], pr["probs"]
    pred = p.argmax(1)
    demo, meth, lang = defaultdict(list), defaultdict(list), defaultdict(list)
    for i, k in enumerate(pr["keys"]):
        inf = by_key[k]
        if inf.get("ethnicity", "unknown") != "unknown":
            demo[f'{inf["ethnicity"]}|{inf["gender"]}'].append(i)
        if inf.get("language", "unknown") not in ("unknown", ""):
            lang[inf["language"]].append(i)
        meth[inf["method"] or inf["label_str"]].append(i)
    out = {"demographic": {}, "language": {}, "generator": {}}
    for name, grp in (("demographic", demo), ("language", lang)):
        out[name] = _group_table(y, p, pred, grp)
    for g, idx in sorted(meth.items()):
        idx = np.array(idx)
        out["generator"][g] = {"n": len(idx), "label": int(np.bincount(y[idx]).argmax()),
                               "4class_recall": float((pred[idx] == y[idx]).mean()),
                               "detected_as_fake": float((pred[idx] != 0).mean())}
    return out


def _group_table(y, p, pred, groups):
    out = {}
    for g, idx in sorted(groups.items()):
        idx = np.array(idx)
        r = {"n": len(idx), "n_per_class": [int((y[idx] == c).sum()) for c in range(4)],
             "acc": accuracy_score(y[idx], pred[idx]),
             "bal_acc": balanced_accuracy_score(y[idx], pred[idx]),
             "macro_f1": f1_score(y[idx], pred[idx], average="macro", zero_division=0)}
        b = binary(y[idx], p[idx])
        r.update({f"bin_{k}": v for k, v in b.items() if k in ("auc", "eer", "bal_acc")})
        out[g] = r
    return out


PLAYERS = ["V_syl", "V_word", "V_sent", "A_syl", "A_word", "A_sent"]


def shapley_stats(pr, by_key):
    """Mean Shapley credit (nats) per player, by class and by generator (GT model only)."""
    if pr.get("phi") is None or pr["phi"].size == 0:
        return None
    groups = defaultdict(list)
    for i, k in enumerate(pr["keys"]):
        groups["class:" + CLASS_NAMES[pr["labels"][i]]].append(i)
        groups["gen:" + (by_key[k]["method"] or by_key[k]["label_str"])].append(i)
    return {g: {"n": len(ix), **dict(zip(PLAYERS, pr["phi"][ix].mean(0).round(5).tolist()))}
            for g, ix in sorted(groups.items())}


def sync_stats(pr, by_key):
    """Distribution of learned sync scores per class and generator (valid scales only)."""
    out = {}
    if pr["s"].size == 0:
        return out
    groups = defaultdict(list)
    for i, k in enumerate(pr["keys"]):
        groups["class:" + CLASS_NAMES[pr["labels"][i]]].append(i)
        groups["gen:" + (by_key[k]["method"] or by_key[k]["label_str"])].append(i)
    for g, idx in sorted(groups.items()):
        idx = np.array(idx)
        row = {}
        for k, nm in enumerate(("syllable", "word", "sentence")):
            ok = pr["sync_valid"][idx, k] > 0.5
            v = pr["s"][idx, k][ok]
            row[nm] = {"valid_frac": float(ok.mean()), "mean": float(v.mean()) if len(v) else None,
                       "std": float(v.std()) if len(v) else None,
                       "q25_50_75": np.percentile(v, [25, 50, 75]).tolist() if len(v) else None}
        out[g] = row
    return out


def bootstrap_ci(y, probs_list, fn, n_boot=1000, seed=0):
    """Stratified bootstrap over test samples of fn(y, mean-over-seeds probs) -> (lo, hi)."""
    rng = np.random.default_rng(seed)
    pm = np.mean(probs_list, 0)
    by_c = [np.where(y == c)[0] for c in np.unique(y)]
    vals = []
    for _ in range(n_boot):
        idx = np.concatenate([rng.choice(ix, len(ix)) for ix in by_c])
        try:
            vals.append(fn(y[idx], pm[idx]))
        except ValueError:
            pass
    return tuple(np.percentile(vals, [2.5, 97.5]).tolist()) if vals else (np.nan, np.nan)


def holdout_report(pr, by_key, token):
    """Unseen-generator protocol: detection on test videos whose generator contains `token`."""
    idx = [i for i, k in enumerate(pr["keys"]) if token in method_tokens(by_key[k]["method"])]
    real = [i for i, k in enumerate(pr["keys"]) if pr["labels"][i] == 0]
    if not idx:
        return None
    sel = np.array(idx + real)
    yb = (pr["labels"][sel] != 0).astype(int)
    score = 1 - pr["probs"][sel, 0]
    r = {"n_unseen": len(idx), "n_real": len(real),
         "unseen_detected_as_fake": float((pr["probs"][idx].argmax(1) != 0).mean()),
         "unseen_4class_recall": float((pr["probs"][idx].argmax(1) == pr["labels"][idx]).mean())}
    if 0 < yb.sum() < len(yb):
        r["auc_unseen_vs_real"] = roc_auc_score(yb, score)
        r["eer_unseen_vs_real"] = eer(yb, score)
    return r
