"""
havdnet_v2.py -- HAVDNet-v2 (sync-gated MoE) and HAVDNet-GT (fusion="shapley", see game_theory.py).

Pipeline per scale k in {syllable, word, sentence}:
  visual encoder  -> per-segment visual sequence v_k  (B, N_k, .)
  audio projection-> per-segment audio sequence  a_k  (B, N_k, .)   (XLSR features are cached)
  entropy dynamics on learnable projections of v_k, a_k, masked per sample
  sync score s_k = gated mix of {Pearson, PLV, soft-DTW} on z-scored entropy trajectories
  fused feature  f_k = W_k [masked-mean(v_k) || masked-mean(a_k)]
Fusion: level weights alpha = g([s, valid]); router w = r([s, valid]);
        f = sum_i w_i E_i(concat(alpha_k f_k))         (sync-gated mixture of experts)
Head:   logits = MLP([f, s, valid, alpha]);  optional generator head on f.

forward(batch) takes NO labels: there is no label-dependent path at train or test time.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from game_theory import ShapleyFusion

DEFAULT_CFG = dict(
    fusion="moe",                  # moe | concat | xattn | transformer | shapley (game-theoretic)
    alloc="proportional",          # shapley: proportional | softmax | uniform
    value="info",                  # shapley: info (log C - H) | conf (max log-prob)
    gate_src="sync",               # sync | feat | uniform     (router input, MoE only)
    level_gate="mlp",              # mlp | text | none
    n_experts=4,
    scales=(0, 1, 2),              # subset of syllable/word/sentence used
    modality="av",                 # av | v | a
    sync=True,                     # False -> no entropy / sync branch at all
    entropy=True,                  # False -> sync metrics on projected features directly
    metrics=("corr", "plv", "sdtw"),
    ws=(5, 4, 4), groups=(16, 16, 32), min_len=3, gamma=0.1,
    d=256, dropout=0.2, n_methods=0,
)
V_DIMS, A_DIMS, DYN_DIMS = (128, 1024, 512), (128, 256, 512), (128, 256, 512)
from common import MAX_SYL, MAX_WORD, MAX_SENT
MAX_N = (MAX_SYL, MAX_WORD, MAX_SENT)


# ====================================================================== utilities
def lengths_mask(L, N):
    return torch.arange(N, device=L.device)[None] < L[:, None]


def masked_mean(x, L):
    m = lengths_mask(L, x.shape[1]).to(x.dtype)[..., None]
    return (x * m).sum(1) / m.sum(1).clamp(min=1)


def sampen_batched(x, m=2, r=0.15, beta=10.0):
    """(N, W, d) -> (N,). Same estimator as the original DiffSampEn, vectorised."""
    N, W, _ = x.shape
    if W < m + 2:
        return x.new_zeros(N)
    fn = F.normalize(x, dim=-1)
    dist = 1.0 - fn @ fn.transpose(1, 2)
    thr = r * dist.std(dim=(-2, -1), keepdim=True).detach()
    sm = torch.sigmoid(beta * (thr - dist)) * (1 - torch.eye(W, device=x.device, dtype=x.dtype))
    Lw = W - m
    tmpl = torch.ones(N, Lw, Lw, device=x.device, dtype=x.dtype)
    for k in range(m):
        tmpl = tmpl * sm[:, k:k + Lw, k:k + Lw]
    up = torch.triu(torch.ones(Lw, Lw, device=x.device, dtype=torch.bool), 1)
    Bc = (tmpl * up).sum((-2, -1))
    Ac = (tmpl * sm[:, m:m + Lw, m:m + Lw] * up).sum((-2, -1))
    return -torch.log((Ac + 1e-8) / (Bc + 1e-8))


class MaskedEntropy(nn.Module):
    """(B,T,D), lengths -> entropy (B,T_out,g), window validity (B,T_out)."""
    def __init__(self, ws, groups, m=2, r=0.15):
        super().__init__()
        self.ws, self.g, self.m, self.r = ws, groups, m, r

    def forward(self, x, L):
        B, T, D = x.shape
        g = min(self.g, D)
        gs = D // g
        if T < self.ws:
            return x.new_zeros(B, 1, g), torch.zeros(B, 1, dtype=torch.bool, device=x.device)
        win = x[..., :g * gs].reshape(B, T, g, gs).unfold(1, self.ws, 1)        # (B,To,g,gs,ws)
        To = win.shape[1]
        e = sampen_batched(win.permute(0, 1, 2, 4, 3).reshape(-1, self.ws, gs), self.m, self.r).view(B, To, g)
        valid = (torch.arange(To, device=x.device)[None] + self.ws) <= L[:, None]
        return e * valid[..., None], valid


def hilbert_phase(x):
    """(B,T,C) real -> instantaneous phase via the complex analytic signal."""
    T = x.shape[1]
    x = x - x.mean(1, keepdim=True)
    h = torch.zeros(T, device=x.device, dtype=x.dtype)
    h[0] = 1
    if T % 2 == 0:
        h[T // 2] = 1
        h[1:T // 2] = 2
    else:
        h[1:(T + 1) // 2] = 2
    return torch.angle(torch.fft.ifft(torch.fft.fft(x, dim=1) * h[None, :, None], dim=1))


def soft_dtw_batched(v, a, L, gamma=0.1):
    """Anti-diagonal (wavefront) soft-DTW: 2T sequential steps instead of T^2.
    Inputs are zero beyond each sample's length; R[i,j] depends only on prefixes, so reading
    R[L_b, L_b] gives the exact unpadded value. Returns exp(-R/2L) in (0, 1]."""
    B, T, _ = v.shape
    c = (v[:, :, None] - a[:, None]).pow(2).mean(-1)                           # (B,T,T)
    inf = torch.full((B, 1), float("inf"), device=v.device, dtype=v.dtype)
    i = torch.arange(1, T + 1, device=v.device)
    diags = [torch.cat([torch.zeros_like(inf), inf.expand(B, T)], 1), inf.expand(B, T + 1)]
    for d in range(2, 2 * T + 1):
        j = d - i
        ok = (j >= 1) & (j <= T)
        jc = j.clamp(1, T)
        nb = torch.stack([diags[d - 2][:, i - 1], diags[d - 1][:, i - 1], diags[d - 1][:, i]], -1)
        nb = torch.where(ok[None, :, None], nb, torch.zeros_like(nb))
        new = c[:, i - 1, jc - 1] - gamma * torch.logsumexp(-nb / gamma, -1)
        diags.append(torch.cat([inf, torch.where(ok[None], new, inf.expand(B, T))], 1))
    D = torch.stack(diags, 1)
    Lc = L.clamp(1, T)
    return torch.exp(-D[torch.arange(B, device=v.device), 2 * Lc, Lc] / (2 * Lc))


class SyncScore(nn.Module):
    """Gated mix of {corr, plv, sdtw} on per-sample z-scored trajectories.
    Returns s (B,), gate (B,M), raw metrics (B,M), ok (B,) -- ok=False -> sentinel 0.5."""
    def __init__(self, metrics, min_len=3, gamma=0.1):
        super().__init__()
        self.metrics, self.min_len, self.gamma = tuple(metrics), min_len, gamma
        M = len(self.metrics)
        self.gate = nn.Sequential(nn.Linear(M, 16), nn.ReLU(), nn.Linear(16, M)) if M > 1 else None

    def forward(self, ev, ea, valid):
        B, T, C = ev.shape
        L = valid.sum(1)
        vm = valid[..., None].to(ev.dtype)
        n = vm.sum(1, keepdim=True).clamp(min=1)

        def zs(x):
            mu = (x * vm).sum(1, keepdim=True) / n
            sd = (((x - mu) * vm).pow(2).sum(1, keepdim=True) / n + 1e-6).sqrt()
            return (x - mu) / sd * vm

        v, a = zs(ev), zs(ea)
        ok = L >= self.min_len
        out = []
        for name in self.metrics:
            if name == "corr":
                out.append(((v * a).sum(1) / n.squeeze(1)).mean(-1).clamp(-1, 1).add(1).div(2))
            elif name == "plv":
                vals = []
                for b in range(B):
                    lb = int(L[b])
                    if lb < self.min_len:
                        vals.append(v.new_tensor(0.5))
                        continue
                    dph = hilbert_phase(v[b:b + 1, :lb]) - hilbert_phase(a[b:b + 1, :lb])
                    vals.append((torch.cos(dph).mean(1).pow(2) + torch.sin(dph).mean(1).pow(2) + 1e-8).sqrt().mean())
                out.append(torch.stack(vals))
            elif name == "sdtw":
                out.append(soft_dtw_batched(v, a, L, self.gamma))
            else:
                raise ValueError(name)
        m = torch.stack(out, -1)
        m = torch.where(ok[:, None], m, torch.full_like(m, 0.5))
        g = torch.softmax(self.gate(m.detach()), -1) if self.gate is not None else torch.ones_like(m)
        s = (m * g).sum(-1)
        return s, g, m, ok


# ====================================================================== encoders
class LipEncoder(nn.Module):
    """(B,N,T,3,48,96) -> (B,N,128); only valid segments are encoded."""
    def __init__(self, out=128):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(), nn.AdaptiveAvgPool2d(1))
        self.gru = nn.GRU(128, out, batch_first=True)
        self.proj = nn.Linear(out, out)
        self.out = out

    def forward(self, x, L):
        B, N, T = x.shape[:3]
        mask = lengths_mask(L, N)
        res = x.new_zeros(B, N, self.out, dtype=torch.float32)
        sel = x[mask]
        if sel.shape[0] == 0:
            return res
        M = sel.shape[0]
        f = self.cnn(sel.float().flatten(0, 1)).view(M, T, 128)
        h, _ = self.gru(f)
        res[mask] = self.proj(h.mean(1)).to(res.dtype)
        return res


class WordEncoder(nn.Module):
    """cached CLIP (B,N,T,512) -> residual refinement -> [mean || std] over frames (B,N,1024)."""
    def __init__(self):
        super().__init__()
        self.refine = nn.Sequential(nn.Linear(512, 512), nn.GELU(), nn.Linear(512, 512))

    def forward(self, x):
        x = x.float()
        r = x + self.refine(x)
        return torch.cat([r.mean(2), r.std(2, unbiased=False)], -1)


def proj(i, o):
    return nn.Sequential(nn.Linear(i, o), nn.LayerNorm(o))


def mlp(i, h, o, p=0.2):
    return nn.Sequential(nn.LayerNorm(i), nn.Linear(i, h), nn.GELU(), nn.Dropout(p), nn.Linear(h, o))


# ====================================================================== fusion variants
class MoEFusion(nn.Module):
    def __init__(self, d, k, gate_src, p):
        super().__init__()
        self.gate_src, self.k = gate_src, k
        self.experts = nn.ModuleList(mlp(3 * d, 2 * d, d, p) for _ in range(k))
        gin = 6 if gate_src == "sync" else 3 * d
        self.router = nn.Sequential(nn.Linear(gin, 32), nn.ReLU(), nn.Linear(32, k))
        self.out = nn.Sequential(nn.Linear(d, d), nn.LayerNorm(d), nn.GELU())

    def forward(self, fhat, alpha, s, sv):
        x = torch.cat([alpha[:, i:i + 1] * fhat[i] for i in range(3)], -1)
        if self.gate_src == "uniform":
            w = x.new_full((x.shape[0], self.k), 1.0 / self.k)
        else:
            w = torch.softmax(self.router(torch.cat([s, sv], -1) if self.gate_src == "sync" else x), -1)
        f = sum(w[:, i:i + 1] * e(x) for i, e in enumerate(self.experts))
        return self.out(f), w


class ConcatFusion(nn.Module):
    def __init__(self, d, p):
        super().__init__()
        self.net = mlp(3 * d, 2 * d, d, p)

    def forward(self, fhat, *_):
        return self.net(torch.cat(fhat, -1)), None


class XAttnFusion(nn.Module):
    """Bidirectional cross-attention between the 3 visual and 3 audio scale tokens."""
    def __init__(self, d, p, heads=4):
        super().__init__()
        self.pv = nn.ModuleList(nn.Linear(x, d) for x in V_DIMS)
        self.pa = nn.ModuleList(nn.Linear(x, d) for x in A_DIMS)
        self.v2a = nn.MultiheadAttention(d, heads, dropout=p, batch_first=True)
        self.a2v = nn.MultiheadAttention(d, heads, dropout=p, batch_first=True)
        self.out = mlp(2 * d, 2 * d, d, p)

    def forward(self, fhat, alpha, s, sv, vbar, abar):
        v = torch.stack([m(x) for m, x in zip(self.pv, vbar)], 1)
        a = torch.stack([m(x) for m, x in zip(self.pa, abar)], 1)
        hv, _ = self.v2a(v, a, a)
        ha, _ = self.a2v(a, v, v)
        return self.out(torch.cat([(v + hv).mean(1), (a + ha).mean(1)], -1)), None


class TransformerFusion(nn.Module):
    def __init__(self, d, p, heads=4, layers=2):
        super().__init__()
        self.pv = nn.ModuleList(nn.Linear(x, d) for x in V_DIMS)
        self.pa = nn.ModuleList(nn.Linear(x, d) for x in A_DIMS)
        self.pos = nn.Parameter(torch.zeros(1, 7, d))
        self.cls = nn.Parameter(torch.zeros(1, 1, d))
        layer = nn.TransformerEncoderLayer(d, heads, 2 * d, p, batch_first=True, norm_first=True)
        self.enc = nn.TransformerEncoder(layer, layers, enable_nested_tensor=False)
        self.out = nn.LayerNorm(d)

    def forward(self, fhat, alpha, s, sv, vbar, abar):
        toks = [m(x) for m, x in zip(self.pv, vbar)] + [m(x) for m, x in zip(self.pa, abar)]
        x = torch.cat([self.cls.expand(toks[0].shape[0], -1, -1), torch.stack(toks, 1)], 1) + self.pos
        return self.out(self.enc(x)[:, 0]), None


class LevelGate(nn.Module):
    def __init__(self, mode, prompt_emb=None):
        super().__init__()
        self.mode = mode
        if mode == "mlp":
            self.net = nn.Sequential(nn.Linear(6, 16), nn.ReLU(), nn.Linear(16, 3))
        elif mode == "text":
            if prompt_emb is None:
                raise ValueError("level_gate=text needs prompts.pt in the store (written by preprocess.py)")
            self.register_buffer("te", prompt_emb.float())
            self.delta = nn.Parameter(torch.zeros_like(self.te))
            self.cls = nn.Sequential(nn.Linear(6, 32), nn.ReLU(), nn.Linear(32, self.te.shape[0]))
            self.net = nn.Sequential(nn.Linear(self.te.shape[1], 64), nn.ReLU(), nn.Linear(64, 3))

    def forward(self, s, sv, active):
        if self.mode == "none":
            logits = torch.zeros_like(s)
        elif self.mode == "mlp":
            logits = self.net(torch.cat([s, sv], -1))
        else:
            z = torch.softmax(self.cls(torch.cat([s, sv], -1)), -1) @ (self.te + self.delta)
            logits = self.net(z)
        return torch.softmax(logits.masked_fill(~active[None], float("-inf")), -1)


# ====================================================================== model
class HAVDNetV2(nn.Module):
    def __init__(self, cfg=None, prompt_emb=None):
        super().__init__()
        self.cfg = c = {**DEFAULT_CFG, **(cfg or {})}
        c["scales"] = tuple(c["scales"]); c["metrics"] = tuple(c["metrics"])
        if c["modality"] != "av":
            c["sync"] = False                       # sync is undefined with one modality
        if not c["sync"] and c["gate_src"] == "sync":
            c["gate_src"] = "feat"
        d, p = c["d"], c["dropout"]
        self.lip = LipEncoder(128)
        self.word = WordEncoder()
        self.sent = proj(512, 512)
        self.aproj = nn.ModuleList(proj(1024, x) for x in A_DIMS)
        self.word_dyn = proj(1024, 256)             # word visual -> same width as word audio for dynamics
        self.ent = nn.ModuleList(MaskedEntropy(c["ws"][k], c["groups"][k]) for k in range(3))
        self.syncs = nn.ModuleList(SyncScore(c["metrics"], c["min_len"], c["gamma"]) for _ in range(3))
        if c["fusion"] != "shapley":
            self.fproj = nn.ModuleList(nn.Linear(V_DIMS[k] + A_DIMS[k], d) for k in range(3))
        self.level = LevelGate(c["level_gate"] if c["fusion"] == "moe" else "none", prompt_emb)
        if c["fusion"] == "shapley":
            self.tok_v = nn.ModuleList(proj(V_DIMS[k], d) for k in range(3))
            self.tok_a = nn.ModuleList(proj(A_DIMS[k], d) for k in range(3))
        self.fusion = {"shapley": lambda: ShapleyFusion(d, 4, c["alloc"], c["value"]),
                       "moe": lambda: MoEFusion(d, c["n_experts"], c["gate_src"], p),
                       "concat": lambda: ConcatFusion(d, p),
                       "xattn": lambda: XAttnFusion(d, p),
                       "transformer": lambda: TransformerFusion(d, p)}[c["fusion"]]()
        n_in = d + 6 + (6 if c["fusion"] == "shapley" else 3)
        self.clf = nn.Sequential(nn.LayerNorm(n_in), nn.Linear(n_in, 256), nn.GELU(), nn.Dropout(0.3),
                                 nn.Linear(256, 128), nn.GELU(), nn.Dropout(0.2), nn.Linear(128, 4))
        self.method_head = mlp(d, d, c["n_methods"], p) if c["n_methods"] else None
        self.register_buffer("f_baseline", torch.zeros(3, d))      # Shapley baseline (set by evaluate.py)
        self.register_buffer("active", torch.tensor([k in c["scales"] for k in range(3)]))

    # ---------------------------------------------------------------- stage 1: encoders
    def encode(self, b):
        L = b["len"].long()                                         # (B,3)
        if self.cfg["modality"] == "a":                             # skip visual compute entirely
            B, dev = L.shape[0], L.device
            v = [torch.zeros(B, MAX_N[k], V_DIMS[k], device=dev) for k in range(3)]
        else:
            v = [self.lip(b["lips"], L[:, 0]), self.word(b["clip_word"]), self.sent(b["arcface"].float())]
        a = [m(x.float()) for m, x in zip(self.aproj, (b["a_syl"], b["a_word"], b["a_sent"]))]
        if self.cfg["modality"] == "v":
            a = [torch.zeros_like(x) for x in a]
        dyn_v = [v[0], self.word_dyn(v[1]), v[2]]
        vbar = [masked_mean(v[k], L[:, k]) for k in range(3)]
        abar = [masked_mean(a[k], L[:, k]) for k in range(3)]
        return {"L": L, "dyn_v": dyn_v, "dyn_a": a, "vbar": vbar, "abar": abar}

    # ---------------------------------------------------------------- stage 2: sync
    def sync(self, e):
        B = e["L"].shape[0]
        dev = e["L"].device
        s = torch.full((B, 3), 0.5, device=dev)
        sv = torch.zeros(B, 3, device=dev)
        raw = [None] * 3
        if not self.cfg["sync"]:
            return s, sv, raw
        s_cols, sv_cols = [], []
        with torch.autocast(device_type=dev.type, enabled=False):
            for k in range(3):
                if k not in self.cfg["scales"]:
                    s_cols.append(s[:, k]); sv_cols.append(sv[:, k]); continue
                xv, xa, Lk = e["dyn_v"][k].float(), e["dyn_a"][k].float(), e["L"][:, k]
                if self.cfg["entropy"]:
                    ev, okv = self.ent[k](xv, Lk)
                    ea, oka = self.ent[k](xa, Lk)
                    valid = okv & oka
                else:
                    ev, ea = xv, xa
                    valid = lengths_mask(Lk, xv.shape[1])
                sk, gk, mk, ok = self.syncs[k](ev, ea, valid)
                s_cols.append(sk); sv_cols.append(ok.float()); raw[k] = {"metrics": mk, "gate": gk}
        return torch.stack(s_cols, -1), torch.stack(sv_cols, -1), raw

    # ---------------------------------------------------------------- stage 3: fusion + heads
    def head_gt(self, e, s, sv, drop_mod=None):
        T = torch.stack([m(x) for m, x in zip(self.tok_v, e["vbar"])] +
                        [m(x) for m, x in zip(self.tok_a, e["abar"])], 1)                  # (B,6,d)
        B = T.shape[0]
        present = torch.cat([self.active, self.active])[None].expand(B, 6).clone()
        if drop_mod == "v":
            present[:, :3] = False
        elif drop_mod == "a":
            present[:, 3:] = False
        if self.cfg["modality"] == "v":
            present[:, 3:] = False
        elif self.cfg["modality"] == "a":
            present[:, :3] = False
        g = self.fusion(T, s, sv, present)
        logits = self.clf(torch.cat([g["f"], s, sv, g["w"].to(g["f"].dtype)], -1))
        return {"logits": logits, "alpha": g["w"], "router": None, "fhat": None, "f": g["f"], "gt": g,
                "method_logits": self.method_head(g["f"]) if self.method_head is not None else None}

    def head(self, e, s, sv, drop=()):
        fhat = [self.fproj[k](torch.cat([e["vbar"][k], e["abar"][k]], -1)) for k in range(3)]
        off = [k for k in range(3) if (k not in self.cfg["scales"]) or (k in drop)]
        if off:
            s, sv = s.clone(), sv.clone()
            for k in off:
                fhat[k] = self.f_baseline[k].expand_as(fhat[k])
                s[:, k], sv[:, k] = 0.5, 0.0
        active = self.active.clone()
        for k in drop:
            active[k] = False
        if not active.any():
            active[:] = True
        alpha = self.level(s, sv, active)
        if self.cfg["fusion"] == "moe":
            f, w = self.fusion(fhat, alpha, s, sv)
        elif self.cfg["fusion"] == "concat":
            f, w = self.fusion(fhat)
        else:
            if drop:
                raise ValueError("Shapley interventions are defined for fusion=moe/concat only")
            f, w = self.fusion(fhat, alpha, s, sv, e["vbar"], e["abar"])
        logits = self.clf(torch.cat([f, s, sv, alpha], -1))
        return {"logits": logits, "alpha": alpha, "router": w, "fhat": fhat, "f": f,
                "method_logits": self.method_head(f) if self.method_head is not None else None}

    def forward(self, batch):
        """batch['drop_mod'] in {None,'a','v'} simulates a missing modality at test time."""
        e = self.encode(batch)
        drop_mod = batch.get("drop_mod")
        if drop_mod:
            key = "abar" if drop_mod == "a" else "vbar"
            e[key] = [torch.zeros_like(x) for x in e[key]]
            B, dev = e["L"].shape[0], e["L"].device
            s, sv, raw = torch.full((B, 3), 0.5, device=dev), torch.zeros(B, 3, device=dev), [None] * 3
        else:
            s, sv, raw = self.sync(e)
        out = self.head_gt(e, s, sv, drop_mod) if self.cfg["fusion"] == "shapley" else self.head(e, s, sv)
        out.update(s=s, sync_valid=sv, sync_raw=raw)
        return out
